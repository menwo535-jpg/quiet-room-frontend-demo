const SCALE = 1000n;
export function mm(value, label = 'Measurement', positive = false) {
  const s = String(value).trim();
  if (!/^\d+(?:\.\d{1,3})?$/.test(s)) throw new Error(`${label}: use a non-negative number with up to 3 decimal places.`);
  const [whole, fraction = ''] = s.split('.');
  const v = BigInt(whole) * SCALE + BigInt(fraction.padEnd(3, '0'));
  if ((positive && v === 0n) || v > 10000000n) throw new Error(`${label}: must be ${positive ? 'greater than zero and ' : ''}at most 10,000 mm.`);
  return v;
}
const ceil = (a, b) => (a + b - 1n) / b;
export const numberMM = v => Number(v) / 1000;
export const format = n => n.toFixed(6).replace(/\.?0+$/, '');
export function solve(input) {
  const l = mm(input.length, 'Board length', true), h = mm(input.height, 'Board height', true);
  const a = mm(input.apex, 'Apex allowance'), f = mm(input.foot, 'Foot allowance');
  const w = mm(input.width, 'Motif width', true), g = mm(input.maxGap, 'Maximum gap');
  if (!['equal', 'flush'].includes(input.mode)) throw new Error('Choose an end-spacing rule.');
  const u = l - a - f;
  if (u < w) throw new Error('The usable run is too short for one motif. Reduce the end allowances or motif width.');
  const numerator = input.mode === 'equal' ? (u > g ? u - g : 0n) : u + g;
  let n = ceil(numerator, w + g);
  if (n < 1n) n = 1n;
  if (n * w > u) throw new Error('No whole motif count satisfies that maximum gap. Increase the maximum gap or change the motif width.');
  if (n > 200n) throw new Error('This sample supports at most 200 motifs. Increase the width or maximum gap.');
  const divisor = input.mode === 'equal' ? n + 1n : n - 1n;
  const remainder = u - n * w;
  if (divisor === 0n && remainder !== 0n) throw new Error('A single flush motif must exactly fill the usable run.');
  const gap = divisor === 0n ? 0 : numberMM(remainder) / Number(divisor);
  const count = Number(n), width = numberMM(w), apex = numberMM(a);
  const endGap = input.mode === 'equal' ? gap : 0;
  return {
    length: numberMM(l), height: numberMM(h), apex, foot: numberMM(f), width,
    maxGap: numberMM(g), mode: input.mode, usable: numberMM(u), count, gap, endGap,
    nextThreshold: numberMM(a + f + n * w + divisor * g),
    starts: Array.from({length: count}, (_, i) => apex + endGap + i * (width + gap)),
    exact: {remainderUm: remainder.toString(), gapDivisor: divisor.toString()}
  };
}
export function svg(s) {
  const cuts = s.starts.map(x => `<rect x="${format(x)}" y="${format(s.height * .3)}" width="${format(s.width)}" height="${format(s.height * .4)}"/>`).join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="${format(s.length)}mm" height="${format(s.height)}mm" viewBox="0 0 ${format(s.length)} ${format(s.height)}">\n<title>Independent rectangular spacing sample</title>\n<desc>Millimetre units. ${s.count} motifs. ${s.mode} end spacing. Not a manufacturing-approved profile.</desc>\n<g fill="none" stroke="rgb(24,52,69)" stroke-width="0.1">\n<rect x="0" y="0" width="${format(s.length)}" height="${format(s.height)}"/>\n${cuts}\n</g>\n</svg>`;
}
export function csv(s) {
  const lines = ['motif,start_mm,centre_mm,end_mm,gap_after_mm'];
  s.starts.forEach((x, i) => lines.push([i + 1, x, x + s.width / 2, x + s.width, i === s.count - 1 ? s.endGap : s.gap].map(format).join(',')));
  return lines.join('\r\n') + '\r\n';
}
