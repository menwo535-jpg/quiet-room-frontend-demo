# Pattern Spacing Lab

Independent sample, 8 October 2026, Xiaolong Pan. This is not commissioned work, a previous customer project, or a manufacturing-approved tool.

Open `spacing-lab.html` in a modern browser. It is a single offline HTML file, with no dependencies or network requests. Source development can use a static server bound to localhost. Rebuild with `python build.py`; check the algorithm with `node --test core.test.mjs`.

## Scope

The sample places fixed-width rectangular motifs along a usable run between two end allowances. It calculates the smallest positive count that keeps the agreed gaps at or below the maximum. Two explicit alternative rules are available: equal end/internal gaps, or zero end gaps and equal internal gaps. No customer-specific motif, apex/foot geometry or cutting rules have been implemented.

For usable length U, motif width W and maximum gap G, an equal-end layout requires `U <= nW + (n+1)G`; a flush layout requires `U <= nW + (n-1)G`. A count must also fit, `nW <= U`. When neither condition can hold for a whole count, the sample returns an error instead of silently violating the gap or resizing the motif. A single flush motif is possible only at U=W.

Input millimetres are parsed as exact integer micrometres (up to three decimals). Count decisions use integer arithmetic. Actual positions may be fractional; SVG/CSV positions are rounded to six decimal millimetres. Displayed metrics use three decimals. Bounds: measurements up to 10,000 mm and at most 200 motifs.

## Verification

- Six Node tests passed, including 23,496 combinations compared with an independent brute-force feasible-count check.
- Total length 1200 mm, end allowances 120/90 mm, motif width 50 mm, max gap 80 mm: seven equal-gap motifs with 80 mm gaps. 1199.999 mm remains seven; 1200.001 mm needs eight.
- The same default dimensions with flush ends give nine motifs and 67.5 mm internal gaps. Both policies close the total length correctly.
- Browser: threshold button, both spacing modes, invalid usable length, and reset from an error checked. A button-name collision that broke reset was found and fixed during UI verification.
- SVG and CSV were actually downloaded through the browser at 04:36 Beijing and inspected. The SVG declares width 1200mm, height 140mm, a matching viewBox and RGB strokes. It contains one outline and seven rectangular motifs. The CSV has seven measured rows; first start/centre/end are 200/225/250 mm.
- At a temporary 390px viewport, document width was 375px with no horizontal overflow; cards stacked. Viewport override was restored.
- Evidence: desktop-proof.jpg, mobile-proof.jpg and samples/ (actual browser downloads).

## Remaining work before any client use

Confirm the end-gap convention, actual motif definition and dependence on board height, minimum webs/radii, datum/orientation and the full written brief. Validate true scale with the customer's SVG importer; a browser preview and XML dimensions do not prove that equipment interprets the file correctly. No physical cutting, Rhino/Grasshopper, DXF, decorative design library or partner review has been performed.
