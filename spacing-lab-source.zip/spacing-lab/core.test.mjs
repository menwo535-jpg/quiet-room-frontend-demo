import test from 'node:test'; import assert from 'node:assert/strict';
import {solve, svg, csv} from './core.mjs';
const base = {length:'1200',height:'140',apex:'120',foot:'90',width:'50',maxGap:'80',mode:'equal'};
test('exact threshold and one micron above', () => {
  assert.equal(solve(base).count, 7); assert.equal(solve(base).gap, 80);
  assert.equal(solve({...base,length:'1199.999'}).count,7);
  assert.equal(solve({...base,length:'1200.001'}).count,8);
});
test('flush and equal end rules differ; both close the length', () => {
  for(const mode of ['equal','flush']) { const s = solve({...base,mode});
    assert.ok(Math.abs(s.starts.at(-1)+s.width+s.endGap+s.foot-s.length)<1e-8);
    assert.equal(s.count,mode==='equal'?7:9);
  }
});
test('zero gap and exact one motif; incompatible zero gap rejected', () => {
  assert.equal(solve({...base,length:'260',mode:'flush'}).gap,0);
  assert.equal(solve({...base,length:'310',maxGap:'0'}).count,2);
  assert.throws(()=>solve({...base,length:'311',maxGap:'0'}),/No whole motif/);
});
test('bad inputs and exhausted usable run produce actionable errors', () => {
  for(const x of ['NaN','Infinity','-1','1e3','1.0001','']) assert.throws(()=>solve({...base,length:x}));
  assert.throws(()=>solve({...base,width:'0'}));
  assert.throws(()=>solve({...base,length:'100'}),/too short/);
  assert.throws(()=>solve({...base,mode:'unknown'}),/end-spacing/);
});
test('brute-force feasible counts agree with solver at small boundaries', () => {
  for(const mode of ['equal','flush']) for(let u=1;u<90;u++) for(let w=1;w<13;w++) for(let g=0;g<11;g++) {
    const first=Array.from({length:Math.floor(u/w)},(_,i)=>i+1).find(n=>{
      const d=mode==='equal'?n+1:n-1,r=u-n*w; return d===0?r===0:r<=d*g;
    });
    const input={length:String(u),height:'10',apex:'0',foot:'0',width:String(w),maxGap:String(g),mode};
    if(first===undefined) assert.throws(()=>solve(input));
    else {const s=solve(input);assert.equal(s.count,first);assert.ok(s.gap>=0&&s.gap<=g);}
  }
});
test('true-size SVG and schedule carry physical dimensions', () => {
  const s=solve(base), xml=svg(s);assert.match(xml,/width="1200mm" height="140mm"/);
  assert.match(xml,/viewBox="0 0 1200 140"/);assert.match(xml,/stroke="rgb\(24,52,69\)"/);
  assert.equal((xml.match(/<rect /g)||[]).length,8);
  assert.equal(csv(s).trim().split('\r\n').length,8);
  assert.equal(csv(s).split('\r\n')[1],'1,200,225,250,80');
});
