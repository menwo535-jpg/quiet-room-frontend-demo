import {solve, svg, csv, format} from './core.mjs';
const $ = id => document.getElementById(id), form = $('controls');
let current;
function render() {
  try {
    current = solve(Object.fromEntries(new FormData(form)));
    $('error').hidden = true; $('output').hidden = false;
    const s = current;
    $('count').textContent = s.count;
    $('gap').textContent = format(Number(s.gap.toFixed(3)));
    $('usable').textContent = format(s.usable);
    $('end-note').textContent = `End gap ${format(Number(s.endGap.toFixed(3)))} mm`;
    const margin = s.length * .04, lineY = -s.height * .22;
    $('preview').innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${s.count} rectangular motifs; gap ${format(s.gap)} millimetres" viewBox="${-margin} ${-s.height * .65} ${s.length + 2 * margin} ${s.height * 2.2}"><rect x="0" y="0" width="${s.length}" height="${s.height}" fill="#fffdf5" stroke="#9bab9c" stroke-width="${s.length / 1200}"/><rect x="0" y="0" width="${s.apex}" height="${s.height}" fill="#d7ded2"/><rect x="${s.length - s.foot}" y="0" width="${s.foot}" height="${s.height}" fill="#d7ded2"/>${s.starts.map(x => `<rect x="${x}" y="${s.height * .3}" width="${s.width}" height="${s.height * .4}" fill="#bf7654"/>`).join('')}<g stroke="#829783" stroke-width="${s.length / 1400}"><path d="M0 ${lineY}H${s.length} M0 ${lineY - s.height * .08}v${s.height * .16} M${s.length} ${lineY - s.height * .08}v${s.height * .16}"/></g><text x="${s.length / 2}" y="${-s.height * .35}" text-anchor="middle" fill="#4c6a57" font-family="sans-serif" font-size="${s.length / 65}">${format(s.length)} mm</text></svg>`;
    $('threshold-text').textContent = `Up to ${format(s.nextThreshold)} mm total length: ${s.count} motifs. Above this length, another motif is required (if it fits).`;
    $('step').disabled = s.nextThreshold >= 10000;
    $('rows').innerHTML = s.starts.map((x, i) => `<tr><td>${i + 1}</td><td>${format(x)}</td><td>${format(x + s.width / 2)}</td><td>${format(x + s.width)}</td></tr>`).join('');
  } catch (e) {
    current = undefined; $('output').hidden = true; $('error').hidden = false; $('error').textContent = e.message;
  }
}
form.addEventListener('submit', e => { e.preventDefault(); render(); });
form.addEventListener('change', render);
$('reset-button').addEventListener('click', () => { form.reset(); render(); });
$('step').addEventListener('click', () => { if(current){ form.elements.namedItem('length').value = (current.nextThreshold + .001).toFixed(3); render(); } });
function download(kind) {
  if (!current) return;
  const text = kind === 'svg' ? svg(current) : csv(current);
  const url = URL.createObjectURL(new Blob([text], {type:kind === 'svg' ? 'image/svg+xml;charset=utf-8' : 'text/csv;charset=utf-8'}));
  const a = document.createElement('a'); a.href = url; a.download = `spacing-${current.count}-motifs.${kind}`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$('svg').addEventListener('click', () => download('svg')); $('csv').addEventListener('click', () => download('csv')); render();
