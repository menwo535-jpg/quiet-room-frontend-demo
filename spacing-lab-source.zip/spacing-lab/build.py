from pathlib import Path
import re

root = Path(__file__).resolve().parent
html = (root / 'index.html').read_text(encoding='utf-8')
css = (root / 'style.css').read_text(encoding='utf-8')
core = re.sub(r'^export ', '', (root / 'core.mjs').read_text(encoding='utf-8'), flags=re.M)
app = re.sub(r'^import .*?\n', '', (root / 'app.mjs').read_text(encoding='utf-8'), count=1)
html = html.replace('<link rel="stylesheet" href="style.css">', f'<style>{css}</style>')
html = html.replace('<script type="module" src="app.mjs"></script>', f'<script type="module">\n{core}\n{app}\n</script>')
(root / 'spacing-lab.html').write_text(html, encoding='utf-8')
print('Built spacing-lab.html; no external assets or network calls.')
