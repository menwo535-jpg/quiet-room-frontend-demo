// All names, areas and services below are invented demonstration content.
(function (root, factory) {
  const data = factory();
  if (typeof module === 'object' && module.exports) module.exports = data;
  else root.DirectorySample = data;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  return [
    { id: 'willow-studio', name: 'Willow Movement Studio', area: 'North Quarter', category: 'Movement', summary: 'A fictional neighbourhood studio for gentle movement and getting started at your own pace.', tags: ['Small groups', 'Step-free access'], tone: 'sage' },
    { id: 'mosaic-circle', name: 'Mosaic Community Circle', area: 'East Bank', category: 'Community', summary: 'A sample place to discover local meetups, shared interests and a friendly conversation.', tags: ['Community groups', 'English / 中文'], tone: 'peach' },
    { id: 'claro-language', name: 'Cláro Language Partners', area: 'Central', category: 'Language & learning', summary: 'An imaginary language-learning service with one-to-one practice and flexible sessions.', tags: ['One-to-one', 'English / Español'], tone: 'blue' },
    { id: 'pocket-companion', name: 'Pocket Companion', area: 'West Garden', category: 'Everyday support', summary: 'A fictional support service for planning everyday errands and navigating local resources.', tags: ['Practical support', 'Flexible sessions'], tone: 'lavender' },
    { id: 'morrow-workshop', name: 'Morrow Creative Workshop', area: 'Central', category: 'Community', summary: 'A sample creative space for making things, sharing skills and learning something new.', tags: ['Creative sessions', 'Small groups'], tone: 'peach' },
    { id: 'qinghe-learning', name: '清禾 · Learning Corner', area: 'East Bank', category: 'Language & learning', summary: 'An invented learning corner featuring bilingual conversation and relaxed group activities.', tags: ['中文 / English', 'Beginner-friendly'], tone: 'sage' },
    { id: 'open-path', name: 'Open Path Movement', area: 'West Garden', category: 'Movement', summary: 'A fictional movement programme with welcoming introductions and individual session options.', tags: ['One-to-one', 'Step-free access'], tone: 'blue' },
    { id: 'sunroom-support', name: 'Sunroom Everyday Support', area: 'North Quarter', category: 'Everyday support', summary: 'An imaginary starting point for organising routines and finding useful community resources.', tags: ['Planning support', 'Flexible sessions'], tone: 'lavender' },
  ];
});
