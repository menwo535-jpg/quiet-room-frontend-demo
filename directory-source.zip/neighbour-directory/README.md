# Neighbour — independent directory interface study

A limited, mobile-first single-page prototype made to demonstrate directory interactions. It is an independent sample, not commissioned work or an accepted customer deliverable. All eight provider names, areas and descriptions are invented. There are no real doctors, patients, photos, contact details, bookings or medical recommendations.

## Run

Open `index.html` in a current browser. All HTML, CSS, data and JavaScript are local files; no package installation or external fonts, network APIs or accounts are needed. A static HTTP(S) host can serve the same folder unchanged. If testing locally with Python, run `python -m http.server 8788 --bind 127.0.0.1` from this directory, then open `http://127.0.0.1:8788/`. Use a free port and do not replace an existing service.

Saved items use the dedicated `neighbour-directory-demo:saved:v1` localStorage key. Browsers handle `file:` storage differently; use static HTTP(S) for repeatable persistence tests. When storage is denied or full, saving still works for the current page visit and the page explains that limitation. No information is transmitted.

## Included

- Search names, area, category and feature labels, combined with explicit area/category filters and a saved-only view.
- Case/accent-insensitive token search, with Chinese and supplementary Unicode text supported.
- Local saved list, unsave, invalid-storage recovery and cross-tab storage updates.
- A small accessible-native-dialog profile preview with intentionally no contact or booking actions.
- Explicit ready, loading, empty-directory, no-match, empty-saved-list and bad-data states. The footer selector simulates data-loading scenarios; it is not connected to a backend.
- Entire invalid batches are rejected, including duplicate IDs and malformed Unicode. Provider content is rendered with DOM text APIs, not HTML interpolation.
- Responsive CSS targets 375 px mobile, two-column tablet and three-column desktop; keyboard focus states, labelled inputs, live result count, reduced-motion preference and 44 px action buttons are provided.

## Verify

Run `node --test test_core.cjs test_app.cjs` (or `npm test`). No dependencies are installed. Pure-function tests cover filtering intersections, Unicode, invalid schemas, duplicate IDs and saved-list validation. The small DOM-contract harness checks real application event wiring, state recovery, save/unsave, storage failures and literal rendering of HTML-shaped text; it is **not a browser engine**.

Check manually in the hosting browser before presenting the prototype:

1. At 375 px, check there is no horizontal overflow, controls remain readable and a card/profile can be used by keyboard.
2. At desktop width, check three-column cards, text lengths and focus visibility.
3. Search `claro`, `清禾` and `movement west`; combine area/category/saved filters, then reset.
4. Save a card, refresh, show saved listings and remove the last saved card. Check the view and keyboard focus recover.
5. Preview loading, empty and invalid-data states, then return to ready. Confirm no partial cards appear in the invalid state.
6. Open and close a profile using buttons and Escape; check focus returns to its trigger.
7. With browser storage disabled, check the memory-only notice instead of a false persistence claim.

## Boundaries

No backend, account, real search service, geolocation, payment, contact form or analytics. No PWA manifest or service worker has been added; offline installation and HTTPS behaviour are not claimed. Listings are synthetic, and tags such as step-free access are invented fixture values, not verification of any real service.

The initial implementation was checked locally using the lightweight DOM harness. The coordinator subsequently verified the actual Chrome behaviour documented below. See `verification.json` for the local test run and `browser-verification.json` for current source hashes and browser observations.

## Coordinator browser verification

Chrome desktop and a 375 × 812 viewport were checked on 8 October 2026. Combined filters, Unicode search, zero matches, reload persistence, cross-tab saved lists, profile focus return and loading/empty/invalid recovery were exercised. A clipped mobile selector was fixed by stacking its controls below 420 px. Details and limitations are in `browser-verification.json`. CSS text contrast was calculated separately; this is not full accessibility certification.
