'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const Core = require('./core.js');
const fixture = require('./data.js');
const clone = () => JSON.parse(JSON.stringify(fixture));
const data = Core.validateProviders(fixture);

test('sample has eight distinct validated providers and four filter categories', () => {
  assert.equal(data.length, 8);
  assert.equal(new Set(data.map((item) => item.id)).size, 8);
  assert.equal(Core.facets(data, 'category').length, 4);
  assert.deepEqual(Core.facets(data, 'area'), ['Central', 'East Bank', 'North Quarter', 'West Garden']);
});

test('normalization copies input without altering source records or tags', () => {
  const input = clone();
  input[0].name = '  Willow  ';
  input[0].tags.push(input[0].tags[0]);
  const before = JSON.stringify(input);
  const result = Core.validateProviders(input);
  assert.equal(result[0].name, 'Willow');
  assert.equal(result[0].tags.length, 2);
  assert.equal(JSON.stringify(input), before);
  assert.ok(Object.isFrozen(result[0]) && Object.isFrozen(result[0].tags));
});

test('search is case-insensitive, accent-insensitive and preserves stable order', () => {
  assert.deepEqual(Core.filterProviders(data, { query: 'CLARO' }).map((row) => row.id), ['claro-language']);
  assert.deepEqual(Core.filterProviders(data, { query: '  movement  ' }).map((row) => row.id), ['willow-studio', 'open-path']);
  assert.equal(Core.filterProviders(data, { query: 'does-not-exist' }).length, 0);
});

test('multiple query tokens may match separate fields and all must match', () => {
  assert.deepEqual(Core.filterProviders(data, { query: 'movement west' }).map((row) => row.id), ['open-path']);
  assert.equal(Core.filterProviders(data, { query: 'movement central' }).length, 0);
});

test('area, category, query and saved state intersect instead of replacing one another', () => {
  const filters = { area: 'East Bank', category: 'Language & learning', query: '中文', savedOnly: true };
  assert.deepEqual(Core.filterProviders(data, filters, ['mosaic-circle', 'qinghe-learning']).map((row) => row.id), ['qinghe-learning']);
  assert.equal(Core.filterProviders(data, filters, ['mosaic-circle']).length, 0);
});

test('Chinese, supplementary-plane emoji and composed Unicode work', () => {
  const input = clone();
  input[0].name = '🌿 清禾 Café';
  const rows = Core.validateProviders(input);
  assert.equal(Core.filterProviders(rows, { query: '🌿 清禾 cafe\u0301' }).length, 1);
  assert.equal(Core.filterProviders(rows, { query: 'ＣＡＦＥ' }).length, 1);
  assert.equal(Core.filterProviders(rows, { query: '清禾' }).length, 2);
});

test('unpaired surrogates fail validation; malformed query does not broaden results', () => {
  for (const bad of ['\ud800', '\udfff', 'x\ud800y']) {
    const input = clone();
    input[0].name = bad;
    assert.throws(() => Core.validateProviders(input), /Unicode/);
    assert.equal(Core.filterProviders(data, { query: bad }).length, 0);
  }
});

test('duplicate or invalid IDs reject the whole batch', () => {
  const input = clone();
  input[1].id = input[0].id;
  assert.throws(() => Core.validateProviders(input), /unique/);
  for (const bad of ['', 'bad id', '__proto__', 'UPPER', 'a'.repeat(65)]) {
    const copy = clone();
    copy[0].id = bad;
    assert.throws(() => Core.validateProviders(copy), /unique/);
  }
});

test('malformed schema, sparse records and sparse tags are rejected', () => {
  for (const input of [null, {}, [null], new Array(2), Array(251).fill(fixture[0])]) {
    assert.throws(() => Core.validateProviders(input));
  }
  const input = clone();
  input[0].tags = new Array(1);
  assert.throws(() => Core.validateProviders(input), /Unicode/);
  input[0] = { ...fixture[0], website: 'https://example.invalid' };
  assert.throws(() => Core.validateProviders(input), /unsupported/);
});

test('invalid text length, control characters, tags and tones are rejected', () => {
  for (const change of [{ name: ' ' }, { summary: 'x\u0000y' }, { name: '😀'.repeat(81) }, { tags: ['a','b','c','d','e'] }, { tone: 'arbitrary-css' }]) {
    assert.throws(() => Core.validateProviders([{ ...fixture[0], ...change }]));
  }
  assert.equal(Core.validateProviders([{ ...fixture[0], name: '😀'.repeat(80) }])[0].name.length, 160);
});

test('HTML-shaped labels remain literal text rather than being interpreted or stripped', () => {
  const name = '<img src=x onerror=alert(1)>';
  const rows = Core.validateProviders([{ ...fixture[0], name, summary: '<script>throw 1</script>' }]);
  assert.equal(rows[0].name, name);
  assert.equal(Core.filterProviders(rows, { query: '<img' }).length, 1);
});

test('saved state removes duplicates and obsolete IDs without changing the source', () => {
  const raw = '["willow-studio","willow-studio","old-listing"]';
  assert.deepEqual(Core.readSaved(raw, data.map((row) => row.id)), { ids: ['willow-studio'], warning: false });
  assert.deepEqual(Core.readSaved(null, []), { ids: [], warning: false });
});

test('corrupt, oversized or structurally wrong saved storage fails gracefully', () => {
  for (const raw of ['broken', '{}', '[null]', '["<script>"]', 'x'.repeat(20_001), JSON.stringify(Array(251).fill('willow-studio'))]) {
    assert.deepEqual(Core.readSaved(raw, data.map((row) => row.id)), { ids: [], warning: true });
  }
});

test('save and unsave round-trip cleanly and unknown IDs cannot be added', () => {
  const ids = data.map((row) => row.id);
  const original = ['willow-studio'];
  const next = Core.toggleSaved(original, 'mosaic-circle', ids);
  assert.deepEqual(original, ['willow-studio']);
  assert.deepEqual(next, ['willow-studio', 'mosaic-circle']);
  assert.deepEqual(Core.toggleSaved(next, 'willow-studio', ids), ['mosaic-circle']);
  assert.throws(() => Core.toggleSaved([], 'missing', ids), /unknown/);
});

test('filtering never mutates providers, filters or saved IDs', () => {
  const filters = Object.freeze({ query: 'learning', savedOnly: true });
  const saved = Object.freeze(['qinghe-learning']);
  const before = JSON.stringify(data);
  assert.equal(Core.filterProviders(Object.freeze([...data]), filters, saved).length, 1);
  assert.equal(JSON.stringify(data), before);
});
