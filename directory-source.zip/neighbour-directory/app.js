(function () {
  'use strict';
  const Core = window.DirectoryCore;
  const STORAGE_KEY = 'neighbour-directory-demo:saved:v1';
  const byId = (id) => document.getElementById(id);
  const search = byId('search');
  const area = byId('area');
  const category = byId('category');
  const scenario = byId('scenario');
  const results = byId('results');
  const dialog = byId('profile-dialog');
  const notice = byId('storage-notice');
  let saved = [];
  let savedOnly = false;
  let providers = [];
  let knownIds = [];
  let dataError = false;
  let storageWritable = true;

  // Data is always inserted as text, never HTML, URLs, selectors or event attributes.
  function element(tag, className, content) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (content !== undefined) node.textContent = content;
    return node;
  }

  function showNotice(message) {
    notice.textContent = message;
    notice.hidden = !message;
  }

  try {
    providers = Core.validateProviders(window.DirectorySample);
    knownIds = providers.map((provider) => provider.id);
  } catch (_) {
    dataError = true;
  }

  function loadSaved() {
    try {
      const result = Core.readSaved(window.localStorage.getItem(STORAGE_KEY), knownIds);
      saved = result.ids;
      if (result.warning) showNotice('Your saved list could not be read. You can start a new list here.');
    } catch (_) {
      storageWritable = false;
      showNotice('Browser storage is unavailable. Saved items will last for this page visit only.');
    }
  }
  loadSaved();

  function populate(select, field) {
    for (const value of Core.facets(providers, field)) {
      const option = element('option', '', value);
      option.value = value;
      select.append(option);
    }
  }
  populate(area, 'area');
  populate(category, 'category');

  function avatar(provider) {
    const letters = provider.name.split(/\s+/u).slice(0, 2).map((part) => Array.from(part)[0]).join('');
    const node = element('span', `provider-avatar tone-${provider.tone}`, letters);
    node.setAttribute('aria-hidden', 'true');
    return node;
  }

  function tags(provider) {
    const list = element('ul', 'tags');
    list.setAttribute('aria-label', 'Listing features');
    for (const tag of provider.tags) list.append(element('li', '', tag));
    return list;
  }

  function openProfile(provider) {
    const container = byId('profile-content');
    container.replaceChildren();
    const badge = avatar(provider);
    badge.classList.add('dialog-avatar');
    const title = element('h2', 'dialog-title', provider.name);
    title.id = 'profile-title';
    const summary = element('p', 'dialog-summary', provider.summary);
    summary.id = 'profile-summary';
    container.append(badge, element('p', 'category-label', provider.category), title, element('p', 'provider-area', provider.area), summary, tags(provider));
    dialog.showModal();
  }

  function saveProvider(provider) {
    saved = Core.toggleSaved(saved, provider.id, knownIds);
    if (storageWritable) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
        showNotice('');
      } catch (_) {
        storageWritable = false;
        showNotice('This browser could not save your list. Changes will last for this page visit only.');
      }
    }
    const nowSaved = saved.includes(provider.id);
    render();
    // Re-rendered cards otherwise remove keyboard focus, especially on unsave.
    const replacement = Array.from(results.querySelectorAll('.save-button')).find((button) => button.dataset.providerId === provider.id);
    if (replacement) replacement.focus();
    else byId('saved-toggle').focus();
    byId('announcer').textContent = `${provider.name} ${nowSaved ? 'saved' : 'removed from saved list'}. ${byId('result-count').textContent}`;
  }

  function card(provider) {
    const article = element('article', 'provider-card');
    const top = element('div', 'card-top');
    const isSaved = saved.includes(provider.id);
    const save = element('button', 'save-button', isSaved ? '♥' : '♡');
    save.type = 'button';
    save.dataset.providerId = provider.id;
    save.setAttribute('aria-label', `${isSaved ? 'Remove' : 'Save'} ${provider.name}${isSaved ? ' from saved list' : ''}`);
    save.setAttribute('aria-pressed', String(isSaved));
    save.addEventListener('click', () => saveProvider(provider));
    top.append(avatar(provider), save);
    const view = element('button', 'profile-button', 'View profile');
    view.type = 'button';
    view.setAttribute('aria-label', `View profile: ${provider.name}`);
    const arrow = element('span', '', '↗');
    arrow.setAttribute('aria-hidden', 'true');
    view.append(arrow);
    view.addEventListener('click', () => openProfile(provider));
    article.append(top, element('p', 'category-label', provider.category), element('h3', 'provider-name', provider.name), element('p', 'provider-area', provider.area), element('p', 'provider-summary', provider.summary), tags(provider), view);
    return article;
  }

  function statePanel(title, body, actionLabel, action, loading = false) {
    const panel = element('div', 'state-panel');
    const symbol = element('span', loading ? 'spinner' : 'state-symbol', loading ? '' : '◌');
    symbol.setAttribute('aria-hidden', 'true');
    panel.append(symbol, element('h3', '', title), element('p', '', body));
    if (action) {
      const button = element('button', 'primary-button', actionLabel);
      button.type = 'button';
      button.addEventListener('click', action);
      panel.append(button);
    }
    results.append(panel);
  }

  function ready() {
    scenario.value = 'ready';
    render();
    search.focus();
  }

  function resetFilters() {
    search.value = '';
    area.value = '';
    category.value = '';
    savedOnly = false;
    render();
    search.focus();
  }

  function render() {
    results.replaceChildren();
    byId('saved-count').textContent = String(saved.length);
    byId('saved-toggle').setAttribute('aria-pressed', String(savedOnly));
    byId('section-kicker').textContent = savedOnly ? 'YOUR PERSONAL SHORTLIST' : 'EXPLORE THE DIRECTORY';
    byId('directory-heading').textContent = savedOnly ? 'A few favourites, together' : 'Find your next connection';
    byId('reset-filters').hidden = !(search.value || area.value || category.value || savedOnly);
    const mode = scenario.value;
    results.setAttribute('aria-busy', String(mode === 'loading'));
    const count = byId('result-count');

    if (mode === 'loading') {
      count.textContent = 'Loading demo listings…';
      statePanel('Finding your neighbourhood', 'This preview simulates loading. Return to the ready state to explore the directory.', 'Show ready state', ready, true);
    } else if (dataError || mode === 'invalid') {
      // The scenario uses the actual validator, rather than just hiding healthy cards.
      let rejected = dataError;
      if (!dataError) {
        try { Core.validateProviders([...window.DirectorySample, window.DirectorySample[0]]); }
        catch (_) { rejected = true; }
      }
      count.textContent = rejected ? 'Directory unavailable' : 'Unexpected demo state';
      statePanel('We couldn’t load these listings', 'The sample data did not pass our checks. No partial or incorrect listings are shown.', dataError ? null : 'Return to ready state', dataError ? null : ready);
    } else if (mode === 'empty') {
      count.textContent = '0 demo listings';
      statePanel('A new neighbourhood awaits', 'There are no listings in this sample directory yet. Preview the ready state to see the complete design.', 'Show sample listings', ready);
    } else {
      const matches = Core.filterProviders(providers, { query: search.value, area: area.value, category: category.value, savedOnly }, saved);
      count.textContent = `${matches.length} ${matches.length === 1 ? 'listing' : 'listings'}${savedOnly ? ' in your saved view' : ' to explore'}`;
      if (matches.length) for (const provider of matches) results.append(card(provider));
      else if (savedOnly && saved.length === 0) statePanel('Keep the ones you like', 'Tap a heart on any listing to start your personal shortlist. No account needed.', 'Explore the directory', resetFilters);
      else statePanel('Nothing here just yet', 'Try another name, neighbourhood or type of support. A broader search may help.', 'Clear filters', resetFilters);
    }
    byId('announcer').textContent = count.textContent;
  }

  search.addEventListener('input', render);
  area.addEventListener('change', render);
  category.addEventListener('change', render);
  scenario.addEventListener('change', render);
  byId('reset-filters').addEventListener('click', resetFilters);
  byId('saved-toggle').addEventListener('click', () => { savedOnly = !savedOnly; render(); });
  byId('close-dialog').addEventListener('click', () => dialog.close());
  byId('profile-done').addEventListener('click', () => dialog.close());
  window.addEventListener('storage', (event) => {
    if (event.key !== STORAGE_KEY && event.key !== null) return;
    const result = Core.readSaved(event.key === null ? null : event.newValue, knownIds);
    saved = result.ids;
    showNotice(result.warning ? 'The saved list in another tab could not be read. This view has been reset.' : 'Your saved list was updated in another tab.');
    render();
  });
  render();
})();
