(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.DirectoryCore = api;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';

  const ID = /^[a-z0-9][a-z0-9-]{0,63}$/;
  const ALLOWED_FIELDS = ['id', 'name', 'area', 'category', 'summary', 'tags', 'tone'];
  const TONES = new Set(['sage', 'peach', 'blue', 'lavender']);

  function wellFormed(value) {
    for (let i = 0; i < value.length; i += 1) {
      const code = value.charCodeAt(i);
      if (code >= 0xd800 && code <= 0xdbff) {
        const next = value.charCodeAt(i + 1);
        if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
        i += 1;
      } else if (code >= 0xdc00 && code <= 0xdfff) return false;
    }
    return true;
  }

  function text(value, field, max) {
    if (typeof value !== 'string' || !wellFormed(value)) {
      throw new TypeError(`${field} must be valid Unicode text.`);
    }
    const result = value.trim().normalize('NFC');
    if (!result || Array.from(result).length > max || /[\u0000-\u001f\u007f]/.test(result)) {
      throw new TypeError(`${field} is empty, too long, or contains control characters.`);
    }
    return result;
  }

  // An invalid batch fails together: duplicate identity must not save the wrong card.
  function validateProviders(input) {
    if (!Array.isArray(input) || input.length > 250) {
      throw new TypeError('A directory must be an array of up to 250 entries.');
    }
    const seen = new Set();
    return Array.from(input).map((item) => {
      if (!item || typeof item !== 'object' || Array.isArray(item)) {
        throw new TypeError('Each directory entry must be an object.');
      }
      if (Object.keys(item).some((key) => !ALLOWED_FIELDS.includes(key))) {
        throw new TypeError('A directory entry contains an unsupported field.');
      }
      if (typeof item.id !== 'string' || !ID.test(item.id) || seen.has(item.id)) {
        throw new TypeError('Directory IDs must be valid and unique.');
      }
      seen.add(item.id);
      if (!Array.isArray(item.tags) || item.tags.length > 4) {
        throw new TypeError('Tags must be an array of up to four labels.');
      }
      if (!TONES.has(item.tone)) throw new TypeError('Unknown card tone.');
      return Object.freeze({
        id: item.id,
        name: text(item.name, 'Name', 80),
        area: text(item.area, 'Area', 50),
        category: text(item.category, 'Category', 50),
        summary: text(item.summary, 'Summary', 220),
        tags: Object.freeze([...new Set(Array.from(item.tags).map((tag) => text(tag, 'Tag', 36)))]),
        tone: item.tone,
      });
    });
  }

  function folded(value) {
    return value.normalize('NFKD').replace(/\p{M}/gu, '').toLocaleLowerCase('en').trim().replace(/\s+/gu, ' ');
  }

  // Query tokens are ANDed; accents and case are ignored. Chinese and emoji stay intact.
  function filterProviders(providers, filters = {}, savedIds = []) {
    if (typeof filters.query === 'string' && !wellFormed(filters.query)) return [];
    const query = typeof filters.query === 'string' ? filters.query : '';
    const tokens = folded(query).split(' ').filter(Boolean);
    const saved = new Set(savedIds);
    return providers.filter((provider) => {
      if (filters.area && provider.area !== filters.area) return false;
      if (filters.category && provider.category !== filters.category) return false;
      if (filters.savedOnly && !saved.has(provider.id)) return false;
      const haystack = folded([provider.name, provider.area, provider.category, ...provider.tags].join(' '));
      return tokens.every((token) => haystack.includes(token));
    });
  }

  function facets(providers, field) {
    if (field !== 'area' && field !== 'category') throw new TypeError('Unsupported filter.');
    return [...new Set(providers.map((provider) => provider[field]))].sort((a, b) => a.localeCompare(b, 'en'));
  }

  function readSaved(raw, knownIds) {
    if (raw === null || raw === undefined) return { ids: [], warning: false };
    try {
      if (typeof raw !== 'string' || raw.length > 20_000) throw new TypeError('Invalid saved list.');
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed) || parsed.length > 250 || parsed.some((id) => typeof id !== 'string' || !ID.test(id))) {
        throw new TypeError('Invalid saved list.');
      }
      const known = new Set(knownIds);
      return { ids: [...new Set(parsed)].filter((id) => known.has(id)), warning: false };
    } catch (_) {
      return { ids: [], warning: true };
    }
  }

  function toggleSaved(ids, id, knownIds) {
    if (!knownIds.includes(id)) throw new TypeError('Cannot save an unknown provider.');
    const current = readSaved(JSON.stringify(ids), knownIds).ids;
    return current.includes(id) ? current.filter((entry) => entry !== id) : [...current, id];
  }

  return Object.freeze({ validateProviders, filterProviders, facets, readSaved, toggleSaved, wellFormed });
});
