'use strict';
// Minimal DOM contract tests. This is not a browser layout/accessibility audit.
const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const Core = require('./core.js');
const fixture = require('./data.js');
const appSource = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8');
const KEY = 'neighbour-directory-demo:saved:v1';

function boot(options = {}) {
  const registry = new Map();
  const listeners = {};
  const writes = [];
  const doc = { activeElement: null };
  class Element {
    constructor(tag = 'div') {
      this.tagName = tag.toUpperCase(); this.children = []; this.attributes = {};
      this.events = {}; this.dataset = {}; this.value = ''; this.hidden = false; this.className = '';
      this.classList = { add: (name) => { this.className += ` ${name}`; } };
      this.literal = '';
    }
    set textContent(value) { this.children = []; this.literal = String(value); }
    get textContent() { return this.literal + this.children.map((item) => item.textContent).join(''); }
    set innerHTML(_) { throw new Error('Unsafe HTML rendering API invoked'); }
    set outerHTML(_) { throw new Error('Unsafe HTML rendering API invoked'); }
    insertAdjacentHTML() { throw new Error('Unsafe HTML rendering API invoked'); }
    append(...nodes) { this.children.push(...nodes); }
    replaceChildren(...nodes) { this.literal = ''; this.children = nodes; }
    setAttribute(name, value) { if (/^on/i.test(name)) throw new Error('Dynamic event attribute'); this.attributes[name] = value; }
    addEventListener(name, callback) { this.events[name] = callback; }
    emit(name) { this.events[name]?.({ target: this }); }
    focus() { doc.activeElement = this; }
    showModal() { this.open = true; }
    close() { this.open = false; }
    querySelectorAll(selector) {
      const matches = [];
      const visit = (node) => {
        for (const child of node.children) {
          if (selector.startsWith('.') && child.className.split(' ').includes(selector.slice(1))) matches.push(child);
          visit(child);
        }
      };
      visit(this);
      return matches;
    }
  }
  for (const id of ['search','area','category','scenario','results','profile-dialog','storage-notice','saved-count','saved-toggle','section-kicker','directory-heading','reset-filters','result-count','announcer','profile-content','close-dialog','profile-done']) registry.set(id, new Element());
  registry.get('scenario').value = 'ready';
  doc.getElementById = (id) => registry.get(id);
  doc.createElement = (tag) => new Element(tag);
  const storage = {
    getItem() { if (options.readDenied) throw new Error('storage denied'); return options.saved ?? null; },
    setItem(key, value) { if (options.writeDenied) throw new Error('quota'); writes.push({ key, value }); },
  };
  const win = { DirectoryCore: Core, DirectorySample: options.data ?? fixture, localStorage: storage, addEventListener: (type, callback) => { listeners[type] = callback; } };
  vm.runInNewContext(appSource, { window: win, document: doc });
  return { registry, get: (id) => registry.get(id), writes, listeners, document: doc };
}

test('ready app renders eight cards and wires name/category/area intersection', () => {
  const app = boot();
  assert.equal(app.get('results').children.length, 8);
  app.get('search').value = 'movement'; app.get('search').emit('input');
  assert.equal(app.get('results').children.length, 2);
  app.get('area').value = 'West Garden'; app.get('area').emit('change');
  assert.equal(app.get('results').children.length, 1);
  assert.match(app.get('results').textContent, /Open Path/);
  app.get('category').value = 'Community'; app.get('category').emit('change');
  assert.match(app.get('results').textContent, /Nothing here/);
});

test('save persists IDs and unsave in saved view keeps keyboard focus usable', () => {
  const app = boot();
  app.get('results').querySelectorAll('.save-button')[0].emit('click');
  assert.deepEqual(app.writes, [{ key: KEY, value: '["willow-studio"]' }]);
  assert.equal(app.get('saved-count').textContent, '1');
  assert.equal(app.document.activeElement.dataset.providerId, 'willow-studio');
  app.get('saved-toggle').emit('click');
  assert.equal(app.get('results').children.length, 1);
  app.get('results').querySelectorAll('.save-button')[0].emit('click');
  assert.match(app.get('results').textContent, /Keep the ones you like/);
  assert.equal(app.document.activeElement, app.get('saved-toggle'));
  assert.equal(app.get('saved-count').textContent, '0');
});

test('loading, empty, invalid and recovery scenarios render explicit states', () => {
  const app = boot();
  for (const [scenario, message] of [['loading','Finding your neighbourhood'], ['empty','A new neighbourhood'], ['invalid','couldn’t load']]) {
    app.get('scenario').value = scenario; app.get('scenario').emit('change');
    assert.ok(app.get('results').textContent.includes(message));
    assert.equal(app.get('results').attributes['aria-busy'], String(scenario === 'loading'));
    assert.equal(app.get('results').querySelectorAll('.provider-card').length, 0);
  }
  app.get('results').querySelectorAll('.primary-button')[0].emit('click');
  assert.equal(app.get('scenario').value, 'ready');
  assert.equal(app.get('results').children.length, 8);
});

test('actual invalid sample batch produces no partial provider cards', () => {
  const app = boot({ data: [...fixture, fixture[0]] });
  assert.match(app.get('results').textContent, /couldn’t load/);
  assert.equal(app.get('results').querySelectorAll('.provider-card').length, 0);
});

test('corrupt storage and denied reads/writes show honest memory-only feedback', () => {
  const corrupt = boot({ saved: '{broken' });
  assert.match(corrupt.get('storage-notice').textContent, /could not be read/);
  for (const flags of [{ readDenied: true }, { writeDenied: true }]) {
    const app = boot(flags);
    app.get('results').querySelectorAll('.save-button')[0].emit('click');
    assert.equal(app.get('saved-count').textContent, '1');
    assert.match(app.get('storage-notice').textContent, /this page visit only/);
    assert.equal(app.writes.length, 0);
  }
});

test('HTML-shaped fixture values remain text in both cards and detail dialog', () => {
  const malicious = { ...fixture[0], name: '<img src=x onerror=alert(1)>', summary: '<script>throw 1</script>', tags: ['<b>literal</b>'] };
  const app = boot({ data: [malicious] });
  assert.ok(app.get('results').textContent.includes(malicious.name));
  app.get('results').querySelectorAll('.profile-button')[0].emit('click');
  assert.equal(app.get('profile-dialog').open, true);
  assert.ok(app.get('profile-content').textContent.includes(malicious.summary));
  assert.ok(app.get('profile-content').textContent.includes('<b>literal</b>'));
  const tags = [];
  const visit = (node) => { tags.push(node.tagName); node.children.forEach(visit); };
  visit(app.get('results')); visit(app.get('profile-content'));
  assert.equal(tags.includes('IMG') || tags.includes('SCRIPT') || tags.includes('B'), false);
  app.get('profile-done').emit('click');
  assert.equal(app.get('profile-dialog').open, false);
});

test('cross-tab updates reconcile the saved view and clearing storage empties it', () => {
  const app = boot();
  app.get('saved-toggle').emit('click');
  app.listeners.storage({ key: KEY, newValue: '["qinghe-learning"]' });
  assert.equal(app.get('saved-count').textContent, '1');
  assert.match(app.get('results').textContent, /清禾/);
  app.listeners.storage({ key: null, newValue: null });
  assert.equal(app.get('saved-count').textContent, '0');
  assert.match(app.get('results').textContent, /Keep the ones/);
});
