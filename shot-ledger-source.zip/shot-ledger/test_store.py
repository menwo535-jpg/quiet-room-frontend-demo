import itertools
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from store import Problem, Store


class JobStateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "state.sqlite"
        self.store = Store(self.path)
        self.store.create("shot-01")

    def tearDown(self):
        self.temp.cleanup()

    def send(self, action, attempt=1, key=None, result=None):
        event = {"event_id": key or action, "action": action, "attempt": attempt}
        if result is not None:
            event["result"] = result
        return self.store.event("shot-01", event)

    def test_success_before_running_cannot_regress(self):
        self.send("succeed", result="mock-frame-A")
        reply = self.send("start")
        self.assertEqual(reply["outcome"]["reason"], "attempt_already_terminal")
        self.assertEqual((reply["job"]["state"], reply["job"]["revision"]), ("succeeded", 2))

    def test_all_orders_of_running_and_duplicate_success_converge(self):
        for n, order in enumerate(itertools.permutations(["start", "success-A", "success-B"])):
            job = f"permutation-{n}"
            self.store.create(job)
            for action in order:
                event = {"event_id": action, "action": "start" if action == "start" else "succeed", "attempt": 1}
                if action != "start":
                    event["result"] = "mock-frame-A"
                self.store.event(job, event)
            final = self.store.read(job)
            self.assertEqual((final["state"], final["result"]), ("succeeded", "mock-frame-A"))

    def test_exact_replay_survives_store_reopen(self):
        original = self.send("succeed", result="mock-frame-A")
        self.store = Store(self.path)
        duplicate = self.send("succeed", result="mock-frame-A")
        self.assertTrue(duplicate["duplicate"])
        self.assertEqual(duplicate["outcome"], original["outcome"])
        self.assertEqual(len(duplicate["job"]["events"]), 1)

    def test_duplicate_id_different_content_is_conflict(self):
        self.send("succeed", result="mock-frame-A")
        with self.assertRaises(Problem) as caught:
            self.send("succeed", result="mock-frame-B")
        self.assertEqual(caught.exception.status, 409)
        self.assertEqual(self.store.read("shot-01")["result"], "mock-frame-A")

    def test_late_old_attempt_does_not_overwrite_new_result(self):
        self.send("fail")
        self.send("retry")
        self.send("succeed", 2, "new-success", "mock-frame-B")
        late = self.send("succeed", 1, "old-success", "mock-frame-A")
        self.assertEqual(late["outcome"]["reason"], "stale_attempt")
        self.assertEqual((late["job"]["attempt"], late["job"]["result"]), (2, "mock-frame-B"))

    def test_cancel_holds_until_explicit_retry(self):
        self.send("cancel")
        self.send("succeed", result="mock-frame-A")
        self.assertEqual(self.store.read("shot-01")["state"], "cancelled")
        fresh = self.send("retry")
        self.assertEqual((fresh["job"]["state"], fresh["job"]["result"], fresh["job"]["attempt"]), ("queued", None, 2))

    def test_success_is_terminal_and_not_retriable(self):
        self.send("succeed", result="mock-frame-A")
        for action in ("fail", "cancel", "retry"):
            self.assertFalse(self.send(action)["outcome"]["applied"])
        self.assertEqual(self.store.read("shot-01")["state"], "succeeded")

    def test_concurrent_same_event_one_write(self):
        with ThreadPoolExecutor(max_workers=12) as pool:
            results = list(pool.map(lambda _: self.send("succeed", result="mock-frame-A"), range(16)))
        self.assertEqual(sum(not reply["duplicate"] for reply in results), 1)
        final = self.store.read("shot-01")
        self.assertEqual((len(final["events"]), final["revision"]), (1, 2))

    def test_concurrent_distinct_retry_commands_increment_once(self):
        self.send("fail")
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda n: self.send("retry", key=f"retry-{n}"), range(16)))
        self.assertEqual(sum(reply["outcome"]["applied"] for reply in results), 1)
        self.assertEqual(self.store.read("shot-01")["attempt"], 2)

    def test_same_key_is_scoped_to_job(self):
        self.store.create("shot-02")
        self.send("start")
        reply = self.store.event("shot-02", {"event_id": "start", "action": "start", "attempt": 1})
        self.assertFalse(reply["duplicate"])

    def test_retry_at_limit_remains_readable_terminal_job(self):
        with self.store.connection() as db:
            db.execute("UPDATE jobs SET attempt=1000000,state='failed' WHERE id='shot-01'")
        reply = self.send("retry", 1000000)
        self.assertEqual(reply["outcome"]["reason"], "attempt_limit_reached")
        self.assertEqual((reply["job"]["attempt"], reply["job"]["state"]), (1000000, "failed"))

    def test_future_attempt_recorded_without_state_change(self):
        reply = self.send("succeed", 2, result="mock-frame-A")
        self.assertEqual(reply["outcome"]["reason"], "future_attempt")
        self.assertEqual(reply["job"]["state"], "queued")

    def test_validation_and_missing_job_leave_store_unchanged(self):
        for event in ([], {}, {"event_id": "bad", "action": "start", "attempt": True},
                      {"event_id": "bad", "action": "succeed", "attempt": 1, "result": ""},
                      {"event_id": "bad", "action": "start", "attempt": 1, "extra": 1}):
            with self.assertRaises(Problem):
                self.store.event("shot-01", event)
        with self.assertRaises(Problem) as caught:
            self.store.read("missing")
        self.assertEqual(caught.exception.status, 404)
        self.assertEqual(self.store.read("shot-01")["events"], [])

    def test_chinese_and_emoji_result_survives_store_reopen(self):
        text = "生成结果：蓝色盒子 \U0001f4e6"
        self.send("succeed", result=text)
        saved = Store(self.path).read("shot-01")
        self.assertEqual(saved["result"], text)
        self.assertEqual(saved["events"][0]["payload"]["result"], text)

    def test_unpaired_surrogates_are_input_errors_without_state_changes(self):
        for invalid in ("\ud800", "\udfff", "prefix\ud800suffix"):
            with self.subTest(invalid=repr(invalid)):
                with self.assertRaises(Problem) as caught:
                    self.send("succeed", result=invalid)
                self.assertEqual(caught.exception.status, 400)
                final = self.store.read("shot-01")
                self.assertEqual((final["state"], final["revision"], final["events"]), ("queued", 1, []))


if __name__ == "__main__":
    unittest.main(verbosity=2)
