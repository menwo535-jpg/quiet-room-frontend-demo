import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from store import Problem, Store

ROOT = Path(__file__).resolve().parent


def make_server(port, database):
    store = Store(database)
    expected_origin = f"http://127.0.0.1:{port}"

    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, body, content_type="application/json; charset=utf-8"):
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            path = urlparse(self.path).path
            try:
                if path == "/":
                    self.reply(200, (ROOT / "index.html").read_bytes(), "text/html; charset=utf-8")
                elif path == "/health":
                    self.reply(200, {"status": "ok", "mode": "local_mock_only"})
                elif path.startswith("/api/jobs/"):
                    self.reply(200, store.read(path.removeprefix("/api/jobs/")))
                else:
                    self.reply(404, {"error": "Not found"})
            except Problem as exc:
                self.reply(exc.status, {"error": str(exc)})

        def do_POST(self):
            try:
                if self.headers.get("Origin") not in (None, expected_origin):
                    raise Problem("Use the local demo origin", 403)
                if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
                    raise Problem("Send application/json", 415)
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                except ValueError:
                    raise Problem("Invalid content length")
                if not 0 < length <= 4096:
                    raise Problem("Request size must be 1–4096 bytes", 413)
                try:
                    data = json.loads(self.rfile.read(length))
                except (ValueError, UnicodeError):
                    raise Problem("Invalid JSON")
                if not isinstance(data, dict):
                    raise Problem("JSON object required")
                path = urlparse(self.path).path
                if path == "/api/jobs":
                    if set(data) != {"id"}:
                        raise Problem("A new job requires only an id")
                    self.reply(201, store.create(data["id"]))
                elif path.startswith("/api/jobs/") and path.endswith("/events"):
                    job_id = path[len("/api/jobs/"):-len("/events")]
                    self.reply(200, store.event(job_id, data))
                else:
                    raise Problem("Not found", 404)
            except Problem as exc:
                self.reply(exc.status, {"error": str(exc)})
            except Exception:
                self.reply(500, {"error": "Local store operation failed"})
                raise

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    expected_origin = f"http://127.0.0.1:{server.server_port}"
    return server


def serve(port, database):
    server = make_server(port, database)
    expected_origin = f"http://127.0.0.1:{server.server_port}"
    print(f"Local mock only: {expected_origin} — Ctrl+C to stop", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8846)
    parser.add_argument("--database", default=str(ROOT / "local-jobs.sqlite"))
    arguments = parser.parse_args()
    serve(arguments.port, arguments.database)
