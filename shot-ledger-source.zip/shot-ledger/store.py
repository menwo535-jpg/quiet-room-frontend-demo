"""Independent local job-state sample. No model calls or customer integration."""
import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


class Problem(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def identifier(value, name):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value):
        raise Problem(f"{name} must contain 1–80 letters, digits, underscores or hyphens")
    return value


class Store:
    def __init__(self, path):
        self.path = str(Path(path))
        with self.connection() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, attempt INTEGER NOT NULL, state TEXT NOT NULL,
                    revision INTEGER NOT NULL, result TEXT, updated TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL REFERENCES jobs(id), event_id TEXT NOT NULL,
                    payload TEXT NOT NULL, outcome TEXT NOT NULL, at TEXT NOT NULL,
                    UNIQUE(job_id, event_id)
                );
            """)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
        finally:
            db.close()

    def read(self, job_id):
        identifier(job_id, "job id")
        with self.connection() as db:
            db.execute("BEGIN")
            return self.snapshot(db, job_id)

    def snapshot(self, db, job_id):
        row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if row is None:
            raise Problem("Job not found", 404)
        result = dict(row)
        result["events"] = [dict(e) for e in db.execute(
            "SELECT seq,event_id,payload,outcome,at FROM events WHERE job_id=? ORDER BY seq", (job_id,)
        )]
        for event in result["events"]:
            event["payload"] = json.loads(event["payload"])
            event["outcome"] = json.loads(event["outcome"])
        return result

    def create(self, job_id):
        identifier(job_id, "job id")
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("INSERT INTO jobs VALUES (?,1,'queued',1,NULL,?)", (job_id, timestamp()))
            except sqlite3.IntegrityError:
                raise Problem("Job id already exists; use a new id", 409)
            result = self.snapshot(db, job_id)
            db.execute("COMMIT")
            return result

    def event(self, job_id, command):
        identifier(job_id, "job id")
        if not isinstance(command, dict):
            raise Problem("Event must be an object")
        event_id = identifier(command.get("event_id"), "event id")
        action = command.get("action")
        if action not in ("start", "succeed", "fail", "cancel", "retry"):
            raise Problem("Unknown action")
        attempt = command.get("attempt")
        if type(attempt) is not int or attempt < 1 or attempt > 1000000:
            raise Problem("attempt must be a positive integer no greater than 1000000")
        if set(command) - {"event_id", "action", "attempt", "result"}:
            raise Problem("Unexpected event fields")
        result = command.get("result")
        if action == "succeed":
            if not isinstance(result, str) or not result.strip() or len(result) > 200:
                raise Problem("Success requires a nonempty mock result of at most 200 characters")
            try:
                result.encode("utf-8")
            except UnicodeEncodeError:
                raise Problem("Success result must contain valid Unicode text")
        elif result is not None:
            raise Problem("Only success events accept a result")
        payload = json.dumps({"action": action, "attempt": attempt, "result": result}, sort_keys=True)
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            job = self.snapshot(db, job_id)
            previous = db.execute("SELECT payload,outcome FROM events WHERE job_id=? AND event_id=?", (job_id, event_id)).fetchone()
            if previous:
                if previous["payload"] != payload:
                    raise Problem("Event id reused with different content", 409)
                return {"duplicate": True, "outcome": json.loads(previous["outcome"]), "job": job}
            outcome = {"applied": False, "reason": "", "attempt": job["attempt"], "revision": job["revision"]}
            next_state, next_attempt, next_result = job["state"], job["attempt"], job["result"]
            if attempt != job["attempt"]:
                outcome["reason"] = "stale_attempt" if attempt < job["attempt"] else "future_attempt"
            elif action == "retry":
                if job["state"] in ("failed", "cancelled") and job["attempt"] == 1000000:
                    outcome["reason"] = "attempt_limit_reached"
                elif job["state"] in ("failed", "cancelled"):
                    next_state, next_attempt, next_result = "queued", job["attempt"] + 1, None
                else:
                    outcome["reason"] = "retry_requires_failed_or_cancelled"
            elif job["state"] in ("succeeded", "failed", "cancelled"):
                outcome["reason"] = "attempt_already_terminal"
            elif action == "start" and job["state"] != "queued":
                outcome["reason"] = "already_running"
            else:
                # A provider success may arrive before its running notification.
                next_state = {"start": "running", "succeed": "succeeded", "fail": "failed", "cancel": "cancelled"}[action]
                next_result = result if action == "succeed" else None
            if not outcome["reason"]:
                outcome.update(applied=True, reason="applied", attempt=next_attempt, revision=job["revision"] + 1)
                db.execute("UPDATE jobs SET attempt=?,state=?,revision=revision+1,result=?,updated=? WHERE id=?",
                           (next_attempt, next_state, next_result, timestamp(), job_id))
            db.execute("INSERT INTO events(job_id,event_id,payload,outcome,at) VALUES (?,?,?,?,?)",
                       (job_id, event_id, payload, json.dumps(outcome), timestamp()))
            response = {"duplicate": False, "outcome": outcome, "job": self.snapshot(db, job_id)}
            db.execute("COMMIT")
            return response
