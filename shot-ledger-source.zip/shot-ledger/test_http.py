import http.client
import json
import tempfile
import threading
import unittest
from pathlib import Path

from server import make_server


class HttpContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "test.sqlite"
        self.start()

    def start(self):
        self.server = make_server(0, self.path)
        self.worker = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.worker.start()

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.worker.join(timeout=3)

    def tearDown(self):
        self.stop()
        self.temp.cleanup()

    def request(self, method, path, value=None, raw=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=3)
        try:
            body = raw if raw is not None else json.dumps(value) if value is not None else None
            connection.request(method, path, body, headers or {"Content-Type": "application/json"})
            response = connection.getresponse()
            return response.status, json.loads(response.read())
        finally:
            connection.close()

    def test_http_restart_and_callback_replay(self):
        self.assertEqual(self.request("POST", "/api/jobs", {"id": "persisted"})[0], 201)
        event = {"event_id": "done", "action": "succeed", "attempt": 1, "result": "mock-frame"}
        first = self.request("POST", "/api/jobs/persisted/events", event)
        self.assertEqual(first[0], 200)
        self.stop()
        self.start()
        final = self.request("GET", "/api/jobs/persisted")
        self.assertEqual((final[0], final[1]["state"], final[1]["result"]), (200, "succeeded", "mock-frame"))
        replay = self.request("POST", "/api/jobs/persisted/events", event)
        self.assertTrue(replay[1]["duplicate"])
        self.assertEqual(replay[1]["outcome"], first[1]["outcome"])
        event["result"] = "different"
        self.assertEqual(self.request("POST", "/api/jobs/persisted/events", event)[0], 409)

    def test_invalid_requests_and_duplicate_creation(self):
        self.assertEqual(self.request("POST", "/api/jobs", {"id": "one"})[0], 201)
        for method, path, value, expected in (
            ("POST", "/api/jobs", {"id": "one"}, 409),
            ("GET", "/api/jobs/missing", None, 404),
            ("POST", "/api/jobs", [], 400),
            ("POST", "/api/jobs", {"id": "two", "extra": 1}, 400),
            ("POST", "/api/jobs/one/events", {"event_id": "a", "action": "start", "attempt": True}, 400),
        ):
            self.assertEqual(self.request(method, path, value)[0], expected)
        self.assertEqual(self.request("POST", "/api/jobs", raw="{")[0], 400)
        self.assertEqual(self.request("POST", "/api/jobs", raw="x" * 4097)[0], 413)
        self.assertEqual(self.request("POST", "/api/jobs", {"id": "two"}, headers={"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.request("GET", "/api/jobs/one")[1]["events"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
