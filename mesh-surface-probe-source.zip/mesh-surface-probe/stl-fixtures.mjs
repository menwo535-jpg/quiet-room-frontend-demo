import { BoxGeometry } from 'three';
export function cubePositions(size=2, dx=0) {
  const g = new BoxGeometry(size,size,size).toNonIndexed();
  const values = new Float32Array(g.attributes.position.array);
  for(let i=0;i<values.length;i+=3) values[i]+=dx;
  g.dispose(); return values;
}
export function binarySTL(values, header='synthetic geometry fixture') {
  const n=values.length/9, buffer=new ArrayBuffer(84+n*50), view=new DataView(buffer);
  new Uint8Array(buffer).set(new TextEncoder().encode(header).slice(0,80));
  view.setUint32(80,n,true);
  for(let t=0;t<n;t++) for(let j=0;j<9;j++) view.setFloat32(84+t*50+12+j*4,values[t*9+j],true);
  return buffer;
}
export function asciiSTL(values) {
  const parts=['solid fixture'];
  for(let i=0;i<values.length;i+=9) {
    parts.push('facet normal 0 0 0','outer loop');
    for(let j=0;j<9;j+=3)parts.push(`vertex ${values[i+j]} ${values[i+j+1]} ${values[i+j+2]}`);
    parts.push('endloop','endfacet');
  }
  parts.push('endsolid fixture');return new TextEncoder().encode(parts.join('\n')).buffer;
}
