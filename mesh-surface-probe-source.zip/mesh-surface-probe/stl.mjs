import { BufferGeometry, Float32BufferAttribute } from 'three';
import { validateGeometry } from './geometry.mjs';

export const MAX_TRIANGLES = 20000;
export const MAX_FILE_BYTES = 6 * 1024 * 1024;

// Deliberately strict triangle-only STL reader. Material/color extensions are
// ignored; no coordinate normalization or implicit unit conversion is applied.
export function parseSTL(buffer) {
  if (!(buffer instanceof ArrayBuffer)) throw new Error('Expected STL file bytes.');
  if (!buffer.byteLength || buffer.byteLength > MAX_FILE_BYTES) throw new Error('STL must be non-empty and at most 6 MiB.');
  const view = new DataView(buffer);
  let values, format;
  const binaryCount = buffer.byteLength >= 84 ? view.getUint32(80, true) : 0;
  if (buffer.byteLength >= 84 && 84 + binaryCount * 50 === buffer.byteLength) {
    if (!binaryCount || binaryCount > MAX_TRIANGLES) throw new Error('STL must contain 1–20,000 triangles.');
    values = new Float32Array(binaryCount * 9);
    for (let t = 0; t < binaryCount; t++) {
      for (let v = 0; v < 9; v++) values[t * 9 + v] = view.getFloat32(84 + t * 50 + 12 + v * 4, true);
    }
    format = 'binary';
  } else {
    let text;
    try { text = new TextDecoder('utf-8', {fatal: true}).decode(buffer); }
    catch { throw new Error('Not valid ASCII STL or exact-length binary STL.'); }
    const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    if (!/^solid(?:\s.*)?$/i.test(lines[0] ?? '') || !/^endsolid(?:\s.*)?$/i.test(lines.at(-1) ?? '')) throw new Error('ASCII STL requires solid and endsolid lines; binary STL length must match its triangle count.');
    const coords = [];
    const number = '[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?';
    const triple = new RegExp(`^vertex\\s+(${number})\\s+(${number})\\s+(${number})$`, 'i');
    const normal = new RegExp(`^facet\\s+normal\\s+(${number})\\s+(${number})\\s+(${number})$`, 'i');
    for (let i = 1; i < lines.length - 1; i += 7) {
      if (coords.length / 9 >= MAX_TRIANGLES) throw new Error('STL must contain 1–20,000 triangles.');
      if (!normal.test(lines[i]) || lines[i + 1]?.toLowerCase() !== 'outer loop' || lines[i + 5]?.toLowerCase() !== 'endloop' || lines[i + 6]?.toLowerCase() !== 'endfacet') throw new Error('Malformed ASCII STL facet.');
      for (let j = 2; j <= 4; j++) {
        const match = triple.exec(lines[i + j] ?? '');
        if (!match) throw new Error('Each STL facet must contain exactly three numeric vertices.');
        coords.push(...match.slice(1).map(Number));
      }
    }
    values = new Float32Array(coords);
    format = 'ascii';
  }
  const geometry = new BufferGeometry().setAttribute('position', new Float32BufferAttribute(values, 3));
  try { validateGeometry(geometry); geometry.computeVertexNormals(); }
  catch (error) { geometry.dispose(); throw error; }
  return {geometry, format, triangles: values.length / 9, bytes: buffer.byteLength};
}
