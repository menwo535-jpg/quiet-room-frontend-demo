import {mkdir,writeFile} from 'node:fs/promises';
import {cubePositions,binarySTL,asciiSTL} from './stl-fixtures.mjs';
import {SphereGeometry} from 'three';
await mkdir('fixtures',{recursive:true});
await writeFile('fixtures/reference-cube.stl',new Uint8Array(binarySTL(cubePositions())));
await writeFile('fixtures/shifted-cube-ascii.stl',new Uint8Array(asciiSTL(cubePositions(2,3))));
await writeFile('fixtures/invalid-degenerate.stl',new Uint8Array(binarySTL(new Float32Array([0,0,0,1,0,0,2,0,0]))));
for (const [name,radius] of [['outer-sphere',2],['inner-sphere',.5]]) {
  const g=new SphereGeometry(radius,48,24).toNonIndexed();
  await writeFile(`fixtures/${name}.stl`,new Uint8Array(binarySTL(g.attributes.position.array)));g.dispose();
}
await writeFile('fixtures/README.txt','Five synthetic STL fixtures: side 2 cubes, A centered at 0, B centered at x=3 (expected surface gap 1 model unit); intentionally degenerate triangle (must reject); concentric polygonal spheres, radii 2 and 0.5 (2208 triangles each), useful for the query-timeout boundary. These are generated examples, not customer files.\n');
console.log('Wrote five synthetic STL fixtures.');
