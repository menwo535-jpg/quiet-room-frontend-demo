import test from 'node:test';
import assert from 'node:assert/strict';
import { Matrix4 } from 'three';
import {parseSTL,MAX_FILE_BYTES,MAX_TRIANGLES} from './stl.mjs';
import {prepare,measureSurfaces} from './geometry.mjs';
import {cubePositions,binarySTL,asciiSTL} from './stl-fixtures.mjs';
const bytes=s=>new TextEncoder().encode(s).buffer;
test('binary and ASCII STL yield identical positions and unit gap',()=>{
  const a=parseSTL(binarySTL(cubePositions())),b=parseSTL(asciiSTL(cubePositions(2,3)));
  assert.equal(a.format,'binary');assert.equal(b.format,'ascii');assert.equal(a.triangles,12);
  assert.deepEqual(a.geometry.attributes.position.array,parseSTL(asciiSTL(cubePositions())).geometry.attributes.position.array);
  const result=measureSurfaces(prepare(a.geometry),new Matrix4(),prepare(b.geometry),new Matrix4());
  assert.equal(result.distance,1);assert.equal(result.surfaceIntersection,false);
});
test('solid prefix in binary header does not change format detection',()=>{
  assert.equal(parseSTL(binarySTL(cubePositions(),'solid this is still binary')).format,'binary');
});
test('truncated binary and extra bytes rejected',()=>{
  const data=binarySTL(cubePositions());
  assert.throws(()=>parseSTL(data.slice(0,-1)),/STL/);
  const extra=new Uint8Array(data.byteLength+1);extra.set(new Uint8Array(data));assert.throws(()=>parseSTL(extra.buffer),/STL/);
});
test('binary advertised triangle count and resource ceilings are enforced',()=>{
  const data=binarySTL(cubePositions());new DataView(data).setUint32(80,999,true);
  assert.throws(()=>parseSTL(data),/STL/);
  assert.throws(()=>parseSTL(new ArrayBuffer(MAX_FILE_BYTES+1)),/6 MiB/);
  const large=new ArrayBuffer(84+(MAX_TRIANGLES+1)*50);new DataView(large).setUint32(80,MAX_TRIANGLES+1,true);
  assert.throws(()=>parseSTL(large),/20,000/);
});
test('empty and nonfinite geometry rejected',()=>{
  assert.throws(()=>parseSTL(bytes('solid e\nendsolid e')),/non-empty/);
  const values=cubePositions();values[0]=Infinity;
  assert.throws(()=>parseSTL(binarySTL(values)),/finite/);
});
test('degenerate triangles rejected in either encoding',()=>{
  const values=new Float32Array([0,0,0,1,0,0,2,0,0]);
  for(const data of [binarySTL(values),asciiSTL(values)])assert.throws(()=>parseSTL(data),/Degenerate/);
});
test('ASCII strict structure rejects missing or extra vertices/facets',()=>{
  const text=new TextDecoder().decode(asciiSTL(cubePositions()));
  assert.throws(()=>parseSTL(bytes(text.replace('outer loop','start loop'))),/Malformed/);
  assert.throws(()=>parseSTL(bytes(text.replace('endloop','vertex 1 2 3\nendloop'))),/Malformed/);
  assert.throws(()=>parseSTL(bytes(text.replace('endsolid fixture',''))),/requires/);
  assert.throws(()=>parseSTL(bytes(text.replace('facet normal','unexpected\nfacet normal'))),/Malformed/);
});
test('ASCII scientific notation, BOM and CRLF accepted without normalization',()=>{
  const data=bytes('\uFEFFsolid test\r\nfacet normal 0 0 1\r\nouter loop\r\nvertex 1e1 0 0\r\nvertex 1.1e1 0 0\r\nvertex 1e1 1 0\r\nendloop\r\nendfacet\r\nendsolid test\r\n');
  const p=parseSTL(data).geometry.attributes.position;
  assert.equal(p.getX(0),10);assert.equal(p.getX(1),11);assert.equal(p.getY(2),1);
});
test('sub-unit triangles remain valid when their shape is not degenerate',()=>{
  const values=new Float32Array([0,0,0,1e-6,0,0,0,1e-6,0]);
  assert.equal(parseSTL(binarySTL(values)).triangles,1);
});
