import { BufferGeometry, Float32BufferAttribute, Matrix4 } from 'three';
import { prepare, measureSurfaces } from './geometry.mjs';
let a, b;
self.onmessage = ({data}) => {
  const {id, operation} = data;
  try {
    if (operation === 'prepare') {
      a?.dispose(); b?.dispose();
      const started = performance.now();
      a = prepare(new BufferGeometry().setAttribute('position', new Float32BufferAttribute(data.a, 3)));
      b = prepare(new BufferGeometry().setAttribute('position', new Float32BufferAttribute(data.b, 3)));
      self.postMessage({id, prepared: true, elapsed: performance.now() - started});
    } else if (operation === 'measure') {
      const started = performance.now();
      const result = measureSurfaces(a, new Matrix4().fromArray(data.matrixA), b, new Matrix4().fromArray(data.matrixB));
      self.postMessage({id, result, elapsed: performance.now() - started});
    } else throw new Error('Unknown worker operation.');
  } catch (error) { self.postMessage({id, error: error.message}); }
};
