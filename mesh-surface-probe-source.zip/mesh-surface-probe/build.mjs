import { build } from 'esbuild';
import { mkdir, readFile, writeFile } from 'node:fs/promises';

const worker = await build({entryPoints: ['query-worker.mjs'], bundle: true, write: false, format: 'iife', minify: true, legalComments: 'inline'});
const result = await build({entryPoints: ['app.mjs'], bundle: true, write: false, format: 'iife', minify: true, legalComments: 'inline', define: {WORKER_SOURCE: JSON.stringify(worker.outputFiles[0].text)}});
await mkdir('dist', {recursive: true});
const template = await readFile('template.html', 'utf8');
await writeFile('dist/mesh-surface-probe.html', template.replace('/* APP_BUNDLE */', () => result.outputFiles[0].text.replaceAll('</script', '<\\/script')));
const notices = await Promise.all(['three', 'three-mesh-bvh'].map(async name => `${name}\n\n${await readFile(`node_modules/${name}/LICENSE`, 'utf8')}`));
await writeFile('dist/THIRD-PARTY-LICENSES.txt', notices.join('\n\n--------------------------\n\n'));
console.log('Built standalone offline HTML and third-party license notices.');
