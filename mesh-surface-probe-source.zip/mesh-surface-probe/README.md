# Mesh Surface Probe

Independent engineering sample by Xiaolong Pan, 8 October 2026.

Open dist/mesh-surface-probe.html in a current browser with WebGL and Blob Worker support. Local ASCII/binary STL import preserves coordinates and model units. Files stay in the browser. Use generated fixtures for the first run. Rebuild: npm ci --ignore-scripts; npm test; npm run build.

17 Node checks cover transforms, nearest surface queries, STL formats and invalid geometry. Chrome verified imported cubes (surface gap 1), rejected degenerate triangles while retaining the prior valid pair, timed out a dense contained pair, reset/recovery, actual JSON export and a 390px layout. Evidence and synthetic fixtures are included. Benchmark medians describe this one machine, not customer performance guarantees.

Limits: rigid transforms only; surface intersection is not solid-containment detection. Positive surface separation does not prove solid objects are collision-free. No registration/alignment, penetration-depth calculation, clinical validation or manufacturing certification. Preparation stops after 5 seconds; a query stops after 2 seconds. File/triangle limits do not guarantee completion. Only synthetic boxes and spheres were tested. AI-assisted implementation; no independent professional review.

Third-party notices: dist/THIRD-PARTY-LICENSES.txt. Third-party libraries perform the underlying queries; this is not a newly invented collision algorithm.
