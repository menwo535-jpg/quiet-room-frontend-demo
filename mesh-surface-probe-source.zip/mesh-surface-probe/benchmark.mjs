import {SphereGeometry,BoxGeometry,Matrix4} from 'three';
import {prepare,measureSurfaces} from './geometry.mjs';
import {mkdir,writeFile} from 'node:fs/promises';
import {cpus,platform,arch} from 'node:os';
const sphere=(radius,segments)=>new SphereGeometry(radius,segments,Math.floor(segments/2));
const scenarios=[
 {name:'subdivided cubes separated',make:()=>[new BoxGeometry(2,2,2,20,20,20),new BoxGeometry(2,2,2,20,20,20)],shift:[3,0,0],expected:1,intersection:false},
 {name:'spheres separated',make:()=>[sphere(1,64),sphere(1,64)],shift:[3,0,0],expected:1,intersection:false},
 {name:'spheres intersecting',make:()=>[sphere(1,64),sphere(1,64)],shift:[.5,.2,.3],expected:0,intersection:true},
 {name:'sphere containment',make:()=>[sphere(2,48),sphere(.5,48)],shift:[0,0,0],expected:1.5,intersection:false,tolerance:.02},
];
const results=[];
for(const item of scenarios){
 const [a,b]=item.make();a.clearGroups();b.clearGroups();
 const started=performance.now();prepare(a);prepare(b);const prepareMs=performance.now()-started;
 const timings=[];let result;
 for(let n=0;n<7;n++){const t=performance.now();result=measureSurfaces(a,new Matrix4(),b,new Matrix4().makeTranslation(...item.shift));timings.push(performance.now()-t);}
 if(Math.abs(result.distance-item.expected)>(item.tolerance??1e-5)||result.surfaceIntersection!==item.intersection)throw new Error(`Geometry oracle failed: ${item.name}`);
 results.push({name:item.name,trianglesA:(a.index?.count??a.attributes.position.count)/3,trianglesB:(b.index?.count??b.attributes.position.count)/3,prepareMs,queryMs:timings,medianMs:[...timings].sort((x,y)=>x-y)[3],result});a.dispose();b.dispose();
 console.log(`${item.name}: ${results.at(-1).medianMs.toFixed(2)}ms median`);
}
await mkdir('evidence',{recursive:true});
await writeFile('evidence/benchmark.json',JSON.stringify({at:new Date().toISOString(),node:process.version,platform:platform(),arch:arch(),cpu:cpus()[0].model,scope:'Synthetic local measurements, 7 queries per case, no customer-performance guarantee. Browser timeout tested separately.',results},null,2));
