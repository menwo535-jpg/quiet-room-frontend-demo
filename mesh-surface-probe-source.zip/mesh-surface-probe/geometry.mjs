import { Box3, Matrix4, Vector3 } from 'three';
import { MeshBVH } from 'three-mesh-bvh';

export function validateGeometry(geometry) {
  const position = geometry.getAttribute('position');
  if (!position || position.itemSize !== 3 || position.count < 3) throw new Error('Expected non-empty triangle positions.');
  const count = geometry.index?.count ?? position.count;
  if (count % 3) throw new Error('Triangle index/vertex count must be divisible by three.');
  for (let i = 0; i < position.count; i++) {
    if (![position.getX(i), position.getY(i), position.getZ(i)].every(Number.isFinite)) throw new Error('All coordinates must be finite.');
  }
  if (geometry.index) {
    for (let i = 0; i < count; i++) {
      const n = geometry.index.getX(i);
      if (!Number.isInteger(n) || n < 0 || n >= position.count) throw new Error('Triangle index is out of range.');
    }
  }
  if (geometry.groups.length || geometry.drawRange.start !== 0 || geometry.drawRange.count !== Infinity) {
    throw new Error('This probe expects a complete geometry without material groups or restricted draw ranges.');
  }
  const vertex = i => new Vector3().fromBufferAttribute(position, geometry.index ? geometry.index.getX(i) : i);
  for (let i = 0; i < count; i += 3) {
    const p = vertex(i), q = vertex(i + 1), r = vertex(i + 2);
    const u = q.clone().sub(p), v = r.clone().sub(p);
    const edgeSq = Math.max(u.lengthSq(), v.lengthSq(), q.distanceToSquared(r));
    // Relative to each triangle's longest edge: reject near-collinear facets
    // at the precision this sample supports, independently of model units.
    if (!edgeSq || u.cross(v).lengthSq() <= edgeSq * edgeSq * 1e-20) throw new Error(`Degenerate or near-collinear triangle at index ${i / 3}.`);
  }
}

function validateRigid(matrix) {
  const e = matrix.elements;
  const tolerance = 1e-6;
  if (!e.every(Number.isFinite) || Math.abs(e[3]) > tolerance || Math.abs(e[7]) > tolerance || Math.abs(e[11]) > tolerance || Math.abs(e[15] - 1) > tolerance) {
    throw new Error('Expected a finite affine transform.');
  }
  const axes = [new Vector3(e[0], e[1], e[2]), new Vector3(e[4], e[5], e[6]), new Vector3(e[8], e[9], e[10])];
  if (axes.some(v => Math.abs(v.lengthSq() - 1) > tolerance) || Math.abs(axes[0].dot(axes[1])) > tolerance || Math.abs(axes[0].dot(axes[2])) > tolerance || Math.abs(axes[1].dot(axes[2])) > tolerance || Math.abs(matrix.determinant() - 1) > tolerance) {
    throw new Error('Only rotation and translation are supported. Bake scale into geometry first.');
  }
}

export function prepare(geometry) {
  validateGeometry(geometry);
  geometry.computeBoundingBox();
  geometry.boundsTree = new MeshBVH(geometry, { indirect: true });
  return geometry;
}

// This is a surface query, not a solid-volume or clinical collision certificate.
export function measureSurfaces(a, matrixA, b, matrixB) {
  validateRigid(matrixA);
  validateRigid(matrixB);
  if (!a.boundsTree || !b.boundsTree) throw new Error('Prepare both geometries before querying.');
  const localB = new Matrix4().copy(matrixA).invert().multiply(matrixB);
  const surfaceIntersection = a.boundsTree.intersectsGeometry(b, localB);
  const nearestA = {}, nearestB = {};
  const result = a.boundsTree.closestPointToGeometry(b, localB, nearestA, nearestB);
  if (!result || !Number.isFinite(result.distance)) throw new Error('No finite surface distance was found.');
  const pointA = nearestA.point.clone().applyMatrix4(matrixA);
  const pointB = nearestB.point.clone().applyMatrix4(matrixB);
  return {
    surfaceIntersection,
    distance: surfaceIntersection ? 0 : result.distance,
    pointA: pointA.toArray(), pointB: pointB.toArray(),
    aabbOverlap: new Box3().copy(a.boundingBox).applyMatrix4(matrixA).intersectsBox(new Box3().copy(b.boundingBox).applyMatrix4(matrixB)),
    containment: 'not_evaluated',
    units: 'model_units',
  };
}
