import test from 'node:test';
import assert from 'node:assert/strict';
import { BoxGeometry, BufferGeometry, Float32BufferAttribute, Matrix4 } from 'three';
import { prepare, measureSurfaces } from './geometry.mjs';

const identity = () => new Matrix4();
const shift = (x, y = 0, z = 0) => new Matrix4().makeTranslation(x, y, z);
const cube = (size = 2) => { const g = new BoxGeometry(size, size, size); g.clearGroups(); return prepare(g); };
const near = (a, b, tolerance = 1e-6) => assert.ok(Math.abs(a - b) < tolerance, `${a} != ${b}`);

test('separated cubes have known gap and nearest points in world frame', () => {
  const r = measureSurfaces(cube(), identity(), cube(), shift(3));
  assert.equal(r.surfaceIntersection, false); assert.equal(r.aabbOverlap, false);
  near(r.distance, 1); near(r.pointA[0], 1); near(r.pointB[0], 2);
});
test('intersecting surfaces are detected', () => {
  const r = measureSurfaces(cube(), identity(), cube(), shift(1.25, 0.2, 0.3));
  assert.equal(r.surfaceIntersection, true); near(r.distance, 0);
});
test('shared global rigid transform preserves gap', () => {
  const global = new Matrix4().makeRotationZ(0.73).setPosition(8, -3, 4);
  const r = measureSurfaces(cube(), global, cube(), global.clone().multiply(shift(3)));
  near(r.distance, 1);
});
test('rotated cube uses local-to-world geometry correctly', () => {
  const rotated = new Matrix4().makeRotationZ(Math.PI / 4).setPosition(3, 0, 0);
  const r = measureSurfaces(cube(), identity(), cube(), rotated);
  near(r.distance, 2 - Math.sqrt(2));
});
test('full containment is NOT reported as collision-free solids', () => {
  const r = measureSurfaces(cube(4), identity(), cube(1), identity());
  assert.equal(r.surfaceIntersection, false); assert.equal(r.aabbOverlap, true);
  assert.equal(r.containment, 'not_evaluated'); near(r.distance, 1.5);
});
test('touching faces return zero surface gap', () => {
  near(measureSurfaces(cube(), identity(), cube(), shift(2)).distance, 0);
});
test('reject scaling instead of returning a wrong distance unit', () => {
  assert.throws(() => measureSurfaces(cube(), new Matrix4().makeScale(2, 1, 1), cube(), shift(5)), /rotation and translation/);
});
test('reject empty and non-finite meshes', () => {
  assert.throws(() => prepare(new BufferGeometry()), /non-empty/);
  const g = new BufferGeometry().setAttribute('position', new Float32BufferAttribute([0, 0, 0, 1, 0, 0, NaN, 1, 0], 3));
  assert.throws(() => prepare(g), /finite/);
});
