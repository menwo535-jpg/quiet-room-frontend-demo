import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { parseSTL, MAX_FILE_BYTES } from './stl.mjs';
const $ = id => document.getElementById(id);
const host = $('canvas-host');
let renderer;
try { renderer = new THREE.WebGLRenderer({antialias: true}); }
catch { $('error').textContent = 'WebGL is unavailable. Source checks can still run with npm test.'; }
if (renderer) {
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); host.appendChild(renderer.domElement);
  renderer.domElement.setAttribute('aria-label', 'Orbit view of two triangle meshes');
  const scene = new THREE.Scene(); scene.background = new THREE.Color('#15212e');
  const camera = new THREE.PerspectiveCamera(40, 1, .01, 1000);
  camera.position.set(7, 5, 9);
  const orbit = new OrbitControls(camera, renderer.domElement); orbit.target.set(1, 0, 0);
  scene.add(new THREE.HemisphereLight(0xcdeaff, 0x1d3143, 2.5));
  const light = new THREE.DirectionalLight(0xffffff, 3); light.position.set(4,8,6); scene.add(light);
  const material = color => new THREE.MeshStandardMaterial({color, roughness:.4, metalness:.1, transparent:true, opacity:.73, side:THREE.DoubleSide});
  const meshA = new THREE.Mesh(undefined, material('#5fd1bd')), meshB = new THREE.Mesh(undefined, material('#829bf7')); scene.add(meshA, meshB);
  const lineGeometry = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]);
  const line = new THREE.Line(lineGeometry,new THREE.LineBasicMaterial({color:'#ffd194',depthTest:false})); line.renderOrder=9; scene.add(line);
  const boxA = new THREE.BoxHelper(meshA,'#407f79'), boxB = new THREE.BoxHelper(meshB,'#6877ac'); scene.add(boxA,boxB);
  const presets = {separated:{a:2,b:2,x:3,angle:0,y:0,z:0},overlap:{a:2,b:2,x:1.25,angle:0,y:.2,z:.3},rotated:{a:2,b:2,x:3,angle:45,y:0,z:0},contained:{a:4,b:1,x:0,angle:0,y:0,z:0}};
  let lastResult=null, worker=null, workerUrl=null, timer=null, flight=null, ready=false, dirty=false, requestId=0, revision=0, source={type:'synthetic'}, importGeneration=0;
  const render=()=>renderer.render(scene,camera);
  function clearMeasurement(message) {
    lastResult=null; line.visible=false; $('gap').textContent='—'; $('bounds').textContent='—'; $('time').textContent='—'; $('status').textContent=message; $('status').className='status'; $('export').disabled=true;
  }
  function stopWorker() { clearTimeout(timer); worker?.terminate(); if(workerUrl) URL.revokeObjectURL(workerUrl); worker=null; workerUrl=null; flight=null; ready=false; }
  function fail(message) { stopWorker(); clearMeasurement('Query unavailable'); $('error').textContent=message; render(); }
  function send(operation, payload, timeout) {
    const id=++requestId; flight={id,operation,revision};
    timer=setTimeout(()=>fail(`${operation==='prepare'?'BVH build':'Surface query'} exceeded ${timeout/1000}s. Models remain visible; reduce triangles or rebuild to retry.`),timeout);
    worker.postMessage({id,operation,...payload});
  }
  function schedule() {
    if(!ready || flight || !dirty) return;
    dirty=false;
    send('measure',{matrixA:meshA.matrixWorld.toArray(),matrixB:meshB.matrixWorld.toArray()},2000);
  }
  function startWorker() {
    stopWorker(); clearMeasurement('Preparing'); $('error').textContent='';
    try {
      workerUrl=URL.createObjectURL(new Blob([WORKER_SOURCE],{type:'text/javascript'})); worker=new Worker(workerUrl);
      worker.onerror=()=>fail('The local geometry worker failed. Rebuild to retry; no successful measurement is available.');
      worker.onmessage=({data})=>{
        if(!flight || data.id!==flight.id) return;
        const completed=flight; flight=null; clearTimeout(timer);
        if(data.error) {fail(data.error); return;}
        if(completed.operation==='prepare') {ready=true; $('build-time').textContent=`BVH build ${data.elapsed.toFixed(2)} ms`; schedule(); return;}
        if(completed.revision===revision) {
          lastResult=data.result;
          $('gap').textContent=lastResult.distance.toFixed(4);
          $('status').textContent=lastResult.surfaceIntersection?'Intersect':'No intersection';
          $('status').className=`status${lastResult.surfaceIntersection?' hit':''}`;
          $('bounds').textContent=lastResult.aabbOverlap?'Overlap':'Separate'; $('time').textContent=`${data.elapsed.toFixed(2)} ms`;
          lineGeometry.setFromPoints([new THREE.Vector3(...lastResult.pointA),new THREE.Vector3(...lastResult.pointB)]);
          line.visible=lastResult.distance>1e-6; $('export').disabled=false; render();
        }
        schedule();
      };
      send('prepare',{a:meshA.geometry.attributes.position.array,b:meshB.geometry.attributes.position.array},5000);
    } catch(error) {fail(error.message);}
  }
  function measure() {
    const x=Number($('x').value),angle=Number($('angle').value);
    $('x-value').textContent=(Math.abs(x)<.005?0:x).toFixed(2); $('angle-value').textContent=`${angle}°`;
    meshB.position.x=x; meshB.rotation.z=THREE.MathUtils.degToRad(angle);
    meshA.updateMatrixWorld(true);meshB.updateMatrixWorld(true);boxA.update();boxB.update();
    revision++;dirty=true;clearMeasurement(worker?'Measuring':'Query unavailable');render();schedule();
  }
  function fit() {
    const box=new THREE.Box3().setFromObject(meshA).union(new THREE.Box3().setFromObject(meshB));
    const center=box.getCenter(new THREE.Vector3()), diagonal=Math.max(box.getSize(new THREE.Vector3()).length(),1e-5);
    orbit.target.copy(center);camera.position.copy(center).add(new THREE.Vector3(1,.7,1.4).normalize().multiplyScalar(diagonal*1.7));
    camera.near=diagonal/1000;camera.far=diagonal*100;camera.updateProjectionMatrix();orbit.update();render();
  }
  function metadata() {
    $('model-info').textContent=`A: ${(meshA.geometry.attributes.position.count/3).toLocaleString()} triangles · B: ${(meshB.geometry.attributes.position.count/3).toLocaleString()} triangles`;
    $('source-info').textContent=source.type==='synthetic'?`Synthetic ${$('preset').selectedOptions[0].textContent}`:`Local STL pair: ${source.a.name} + ${source.b.name}. Coordinates preserved; matching units required.`;
  }
  function replaceGeometry(a,b) {meshA.geometry?.dispose();meshB.geometry?.dispose();meshA.geometry=a;meshB.geometry=b;metadata();}
  function reset() {
    importGeneration++;$('import-error').textContent='';$('file-a').value='';$('file-b').value='';
    const p=presets[$('preset').value]; source={type:'synthetic',preset:$('preset').value};
    const cube=size=>{const g=new THREE.BoxGeometry(size,size,size).toNonIndexed();g.clearGroups();return g;};
    replaceGeometry(cube(p.a),cube(p.b));
    meshA.position.set(0,0,0);meshA.rotation.set(0,0,0);meshB.position.set(p.x,p.y,p.z);
    $('x').min=-4;$('x').max=5;$('x').step=.02;$('x').value=p.x;$('angle').value=p.angle;
    ready=false;measure();startWorker();fit();
  }
  $('import').addEventListener('click',async()=>{
    const a=$('file-a').files[0],b=$('file-b').files[0];const generation=++importGeneration;
    $('import-error').textContent='';let parsedA,parsedB;
    try {
      if(!a||!b) throw new Error('Choose both local STL files before loading.');
      if(a.size>MAX_FILE_BYTES||b.size>MAX_FILE_BYTES) throw new Error('Each STL file must be at most 6 MiB.');
      const buffers=await Promise.all([a.arrayBuffer(),b.arrayBuffer()]);
      if(generation!==importGeneration) return;
      parsedA=parseSTL(buffers[0]);parsedB=parseSTL(buffers[1]);
      source={type:'local_stl',a:{name:a.name,format:parsedA.format,bytes:a.size,triangles:parsedA.triangles},b:{name:b.name,format:parsedB.format,bytes:b.size,triangles:parsedB.triangles}};
      replaceGeometry(parsedA.geometry,parsedB.geometry);parsedA=null;parsedB=null;
      meshA.position.set(0,0,0);meshA.rotation.set(0,0,0);meshB.position.set(0,0,0);meshB.rotation.set(0,0,0);
      const both=new THREE.Box3().setFromObject(meshA).union(new THREE.Box3().setFromObject(meshB));
      const span=Math.max(both.getSize(new THREE.Vector3()).length(),.01);
      $('x').min=-span;$('x').max=span;$('x').step=span/500;$('x').value=0;$('angle').value=0;
      ready=false;measure();startWorker();fit();
    }catch(error){parsedA?.geometry.dispose();parsedB?.geometry.dispose();$('import-error').textContent=`Not loaded: ${error.message} Previous models and their measurement are retained.`;}
  });
  $('preset').addEventListener('change',reset);$('reset').addEventListener('click',reset);$('fit').addEventListener('click',fit);
  $('rebuild').addEventListener('click',()=>{dirty=true;startWorker();});
  $('x').addEventListener('input',measure);$('angle').addEventListener('input',measure);
  $('export').addEventListener('click',()=>{
    if(!lastResult)return;
    const record={sample:'independent mesh surface probe',generatedAt:new Date().toISOString(),source,transformA:meshA.matrixWorld.toArray(),transformB:meshB.matrixWorld.toArray(),...lastResult,scope:'surface queries only; containment not evaluated; not clinical validation'};
    const url=URL.createObjectURL(new Blob([JSON.stringify(record,null,2)],{type:'application/json'}));const anchor=document.createElement('a');anchor.href=url;anchor.download='mesh-surface-measurement.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  orbit.addEventListener('change',render);
  new ResizeObserver(()=>{camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);render();}).observe(host);
  window.addEventListener('pagehide',stopWorker);reset();
}
