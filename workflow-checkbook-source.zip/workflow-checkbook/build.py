from pathlib import Path
root=Path(__file__).parent
html=(root/'index.html').read_text(encoding='utf-8')
css=(root/'style.css').read_text(encoding='utf-8')
core=(root/'core.mjs').read_text(encoding='utf-8').replace('export ','')
app=(root/'app.mjs').read_text(encoding='utf-8').replace("import { runSuite } from './core.mjs';",'')
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
html=html.replace('<script type="module" src="app.mjs"></script>','<script type="module">'+core+'\n'+app+'</script>')
(root/'workflow-checkbook.html').write_text(html,encoding='utf-8')
print('Built workflow-checkbook.html')
