import { runSuite } from './core.mjs';
const $ = id => document.getElementById(id);
const make = (tag, text, className) => { const node = document.createElement(tag); node.textContent = text ?? ''; if (className) node.className = className; return node; };
let report;
let selected = null;
function showCase(id) {
  selected = id;
  for (const item of $('cases').children) item.setAttribute('aria-pressed', String(item.dataset.case === id));
  const current = report.cases.find(x => x.id === id);
  $('detail').replaceChildren();
  const title = make('div', '', 'detail-title'); title.append(make('h2',current.name),make('span',current.id));
  $('detail').append(title,make('p',current.why,'why'));
  current.observations.forEach((observation, index) => {
    const block = make('div','','step'); const heading = make('h3',`Step ${index+1} · ${observation.behavior}`);
    heading.append(make('span',observation.passed?'PASS':'FAIL',`badge ${observation.passed?'':'failed'}`));block.append(heading);
    const comparison = make('div','','comparison');
    for (const [label,value] of [['EXPECTED',observation.expected],['OBSERVED',observation.actual]]) {
      const col = make('div');col.append(make('span',label,'caption'),make('pre',JSON.stringify(value,null,2)));comparison.append(col);
    }
    block.append(comparison);
    if (observation.differences.length) block.append(make('p',observation.differences.map(x=>`${x.field}: expected ${JSON.stringify(x.expected)}, observed ${JSON.stringify(x.actual)}`).join('\n'),'diff'));
    const input = document.createElement('details');input.append(make('summary','Input and full response'),make('pre',JSON.stringify({input:observation.input,response:observation.response},null,2)));block.append(input);
    block.append(make('div','ORDERED TRACE THROUGH THIS STEP','caption'));
    const trace = make('ol','','trace');
    for (const event of observation.trace) trace.append(make('li',`${event.step} ${JSON.stringify(event.detail)}`));
    block.append(trace);$('detail').append(block);
  });
}
async function run() {
  $('run').disabled = true; $('download').disabled = true; $('csv').disabled = true;
  $('status').textContent = 'Running twelve local fixture cases…';
  try {
    report = await runSuite($('mode').value);
    $('pass').replaceChildren(document.createTextNode(String(report.passed)),make('small',`/${report.total}`));
    $('fail').textContent = String(report.total-report.passed);
    $('run-mode').textContent = report.mode==='corrected'?'Corrected reference':'Deliberately defective';
    $('cases').replaceChildren();
    for (const entry of report.cases) {
      const button = make('button','','case');button.dataset.case=entry.id;button.setAttribute('aria-pressed','false');
      button.append(make('span',entry.id),make('strong',entry.name),make('span',entry.passed?'PASS':'FAIL',`badge ${entry.passed?'':'failed'}`));
      button.addEventListener('click',()=>showCase(entry.id));$('cases').append(button);
    }
    showCase(selected && report.cases.some(x=>x.id===selected)?selected:(report.cases.find(x=>!x.passed)?.id??'C01'));
    $('status').textContent=`Completed ${new Date(report.finishedAt).toLocaleTimeString()}. ${report.passed}/${report.total} cases passed. Fixture state was reset between cases.`;
    $('download').disabled=false;$('csv').disabled=false;
  } catch(error) {$('status').textContent=`Run could not complete: ${error.message}`;}
  finally {$('run').disabled=false;}
}
function download(contents,type,extension) {
  const url = URL.createObjectURL(new Blob([contents],{type}));const link=document.createElement('a');
  link.href=url;link.download=`workflow-checkbook-${report.mode}.${extension}`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
const cell = value => '"'+String(value??'').replaceAll('"','""')+'"';
$('run').addEventListener('click',run);
$('mode').addEventListener('change',()=>{$('status').textContent='Fixture selection changed. Run again to update the displayed results.';});
$('download').addEventListener('click',()=>report&&download(JSON.stringify(report,null,2),'application/json','json'));
$('csv').addEventListener('click',()=>{if(!report)return;const rows=[['fixture','case','name','step','passed','expected','observed','differences']];for(const entry of report.cases)entry.observations.forEach((o,i)=>rows.push([report.mode,entry.id,entry.name,i+1,o.passed,JSON.stringify(o.expected),JSON.stringify(o.actual),JSON.stringify(o.differences)]));download(rows.map(row=>row.map(cell).join(',')).join('\r\n'),'text/csv;charset=utf-8','csv');});
