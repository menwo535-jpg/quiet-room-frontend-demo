# Workflow Checkbook

Independent, synthetic functional-QA demonstration. Open `workflow-checkbook.html` directly in a current browser; no installation, client data, external API or paid service is needed.

Choose **Before** and run the suite: the intentionally defective fixture passes only C01. Choose **After**: the reference fixture passes 12/12. Select any case to inspect its expected/observed results, input, response and ordered effect trace. JSON contains the full run; CSV contains one row per observation step.

## Scope

The cases exercise validation, repeated delivery, changed content under the same event ID, pre-write timeout, retry, rate limits, downstream unavailability, and HTTP 200 carrying business rejection. A correct response is insufficient if the side-effect count is wrong. Each case starts with fresh state; steps within a case share state.

The browser demonstration is an in-memory, sequential JavaScript fixture. It is **not** a test of n8n, Vapi, Twilio, ElevenLabs, or any customer's system. It does not establish voice/model quality, concurrency safety, durable idempotency, production readiness or recovery after process restart. Timeout injection occurs before a write; unknown outcomes after a write require reconciliation and are outside this sample. No professional partner review has occurred. AI-assisted implementation.

A separate [actual n8n integration check](n8n/README.md) now runs the same 12 contracts through n8n 2.38.7 and a loopback destination: 12 cases / 15 execution steps passed. It has its own observations and limits; the browser's Before/After buttons still run only the JavaScript fixture.

An optional SQLite destination extends that check to **14 cases / 19 actual n8n executions**, with post-write timeout, clean server restart and replay/conflict checks. Four separate destination HTTP tests also cover concurrent duplicates and scope separation. This does not establish exactly-once effects in external services. See the n8n README for evidence and reproduction; the offline UI remains the 12-case in-memory demonstration.

## Reproduce

`node --test core.test.mjs` runs six checks, including planted defects, an adapter with correct responses but wrong side effects, validation boundaries, mutation isolation, and conflicting event reuse. `python build.py` rebuilds the offline HTML from `index.html`, `style.css`, `core.mjs` and `app.mjs`.

## Actual verification, 2026-10-08

- Six Node tests passed.
- Chrome UI: Before 1/12 and After 12/12; C06 duplicate side effects and C12 business rejection inspected.
- Actual downloaded JSON/CSV files retained in `evidence/` and parsed for consistency.
- 390px viewport: document/body width 375px with vertical scrollbar; no horizontal overflow. Override restored.
- Browser text and desktop/mobile screenshots saved beside this README.

Independent portfolio material only. No client acceptance, commission or payment is implied, and customer acceptance is not implied.
