"""Loopback-only synthetic destination. Optional SQLite replay ledger, never production."""
import argparse
import json
import threading
import time
import sqlite3
import uuid
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class Ledger:
    """The effect and replay record are the same committed row in this fixture."""
    def __init__(self, path):
        self.path = str(path)
        with closing(sqlite3.connect(self.path)) as conn, conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS orders (
                scope TEXT NOT NULL, event_id TEXT NOT NULL,
                fingerprint TEXT NOT NULL, order_id TEXT NOT NULL,
                payload TEXT NOT NULL, PRIMARY KEY(scope, event_id))''')

    def accept(self, scope, order):
        fingerprint = json.dumps(order['items'], sort_keys=True, separators=(',', ':'))
        with closing(sqlite3.connect(self.path, timeout=5)) as conn, conn:
            conn.execute('BEGIN IMMEDIATE')
            old = conn.execute('SELECT fingerprint, order_id FROM orders WHERE scope=? AND event_id=?',
                               (scope, order['eventId'])).fetchone()
            if old:
                status = 200 if old[0] == fingerprint else 409
                return status, {'accepted': status == 200, 'orderId': old[1], 'replay': True}
            order_id = scope + '-' + uuid.uuid4().hex
            conn.execute('INSERT INTO orders VALUES(?,?,?,?,?)',
                         (scope, order['eventId'], fingerprint, order_id, json.dumps(order)))
        # A success response must only be built after the transaction commits.
        return 200, {'accepted': True, 'orderId': order_id, 'replay': False}

    def snapshot(self, scope):
        with closing(sqlite3.connect(self.path)) as conn, conn:
            rows = conn.execute('SELECT event_id,fingerprint,order_id,payload FROM orders WHERE scope=? ORDER BY event_id',
                                (scope,)).fetchall()
        return {'effects': [dict(orderId=r[2], **json.loads(r[3])) for r in rows],
                'events': {r[0]: {'fingerprint': r[1], 'orderId': r[2]} for r in rows}}

def create_server(port=0, ledger_path=None):
    cases = {}
    lock = threading.Lock()
    ledger = Ledger(ledger_path) if ledger_path else None
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            if not self.path.startswith('/cases/') or len(self.path.split('/')) != 3:
                self.send_error(404); return
            case_id=self.path.rsplit('/',1)[1]
            order=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
            behavior=self.headers.get('X-Fixture-Behavior','success')
            with lock:
                state=cases.setdefault(case_id,dict(effects=[],events={},attempts=[]))
                state['attempts'].append(dict(order=order,behavior=behavior))
            if behavior == 'timeout':
                # Delay before any write, then explicitly return without a write.
                time.sleep(1)
                self.respond(504,{'accepted':False}); return
            if behavior == 'rate_limit':
                self.respond(429,{'accepted':False},{'Retry-After':'1'}); return
            if behavior == 'unavailable': self.respond(503,{'accepted':False}); return
            if behavior == 'declined': self.respond(200,{'accepted':False,'reason':'fixture_decline'}); return
            if behavior not in ('success', 'post_write_timeout'): self.respond(400,{'accepted':False}); return
            fingerprint=json.dumps(order['items'],sort_keys=True,separators=(',',':'))
            if ledger:
                status, body = ledger.accept(case_id, order)
            else:
              with lock:
                old=state['events'].get(order['eventId'])
                if old:
                    status=200 if old['fingerprint']==fingerprint else 409
                    body={'accepted':status==200,'orderId':old['orderId'],'replay':True}
                else:
                    order_id=f'{case_id}-order-{len(state["effects"])+1}'
                    state['effects'].append(dict(orderId=order_id,**order))
                    state['events'][order['eventId']]={'fingerprint':fingerprint,'orderId':order_id}
                    status,body=200,{'accepted':True,'orderId':order_id,'replay':False}
            if behavior == 'post_write_timeout':
                # Commit first, lose/delay the response. The client cannot infer zero writes.
                time.sleep(1)
            self.respond(status,body)
        def respond(self,status,body,headers=None):
            encoded=json.dumps(body).encode()
            try:
                self.send_response(status)
                self.send_header('Content-Type','application/json')
                self.send_header('Content-Length',str(len(encoded)))
                for key,value in (headers or {}).items(): self.send_header(key,value)
                self.end_headers(); self.wfile.write(encoded)
            except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError): pass
    class FixtureServer(ThreadingHTTPServer):
        request_queue_size = 32
    server=FixtureServer(('127.0.0.1',port),Handler)
    def snapshot(case_id):
        with lock: result = json.loads(json.dumps(cases.get(case_id,dict(effects=[],events={},attempts=[]))))
        if ledger: result.update(ledger.snapshot(case_id))
        return result
    server.snapshot=snapshot
    return server

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8850)
    parser.add_argument('--ledger',help='Optional local SQLite fixture ledger path')
    args=parser.parse_args()
    server=create_server(args.port, args.ledger)
    print(f'Synthetic destination: http://127.0.0.1:{server.server_port}; Ctrl+C to stop.',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
