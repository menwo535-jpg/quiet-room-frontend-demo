# Actual n8n integration check

This extends the browser-only Workflow Checkbook with **real n8n 2.38.7 CLI executions** and a loopback HTTP destination. It is an independent synthetic sample, not a customer deployment or a voice-agent assessment.

The run on 2026-10-08 passed **12 cases / 15 execution steps**. The verifier reads n8n's execution object, checks the actual branch output, and separately counts writes in the destination. An exit code or an HTTP 200 alone does not prove success. Full observations are in `evidence/validation.json`.

An additional SQLite-ledger run passed **14 cases / 19 n8n execution steps**, including all 12 baseline cases. Its evidence is `evidence-durable/validation.json`. Four separate loopback HTTP checks passed in `ledger.test.py` (`evidence/ledger-tests.txt`). These are distinct runs, not browser simulation results.

| Case | Verified outcome |
|---|---|
| Valid order | One record, confirmed with an order ID |
| Missing ID, empty list, fractional or zero quantity | Rejected before the HTTP node; zero destination attempts |
| Same event twice | Same order ID; one record in total |
| Same ID, changed payload | Conflict; no second record |
| Actual network timeout | n8n reports ECONNABORTED; mapped to a retryable failure |
| Retry after pre-write timeout | The successful retry creates one record |
| HTTP 429 | Deferred, Retry-After value preserved |
| HTTP 503 | Retryable failure |
| HTTP 200 with accepted=false | Declined, no record |

## Baseline responsibilities and limits

- In the baseline run, the destination owns in-memory idempotency. The sample does not claim that n8n itself stores a durable replay ledger.
- Each case has independent state; steps inside a case share it. The baseline does not test concurrency or restart; the separate durable experiment below does.
- Baseline timeout is injected **before a destination write**. Post-write ambiguity is tested only in the separate durable experiment below; external-service retry safety is not established.
- The workflow starts from a manual synthetic-input node, not a tested HTTP webhook. Output status numbers are JSON fields, not responses from an exposed webhook.
- No hosted environment, customer data, live calls, Vapi/Twilio, LLM output or production traffic is involved. No partner review has taken place. Implementation is AI-assisted.
- The local destination has no authentication because it is synthetic and listens only on 127.0.0.1. It must not be exposed publicly.

## Optional durable destination experiment

With `--durable`, the destination uses SQLite. The business record and replay record are the same row, keyed by the synthetic case scope and event ID. A transaction checks the existing fingerprint or commits the new row before returning success. Database connections are explicitly closed; an initial Windows cleanup failure exposed and helped fix a connection-lifetime bug.

The extra cases show why a timeout alone does not prove zero writes:

- **C13:** commit one row, delay the response until n8n times out, stop/recreate the destination server, then retry the same event. The response returns the original order ID with `replay=true`; the persisted record count remains one.
- **C14:** commit before a timeout, then retry that event ID with changed quantity. The destination responds with a conflict and keeps the original single row.
- Separate HTTP tests send 16 identical requests concurrently and observe one created row, 15 replays and the same returned ID. Two concurrent requests with different payloads produce one success and one conflict. Identical event IDs in distinct fixture scopes remain independent.

This is **not** an exactly-once guarantee for calls to an external payment, email or CRM service: such side effects are not in the same SQLite transaction. The restart is a clean server restart, not a power failure, crash during commit or a distributed-worker test. Concurrent requests exercise the HTTP destination, while n8n CLI executions are sequential. `retryable_failure` is an outcome label, not permission to retry blindly; the workflow has automatic HTTP retries disabled. A real integration needs the destination's documented idempotency/reconciliation contract.

## Reproduce

Use Python 3.12, Node 24 and a separately installed n8n **2.38.7** from its normal npm package. From this folder:

```text
python verify.py --node node --n8n-bin /absolute/path/to/node_modules/n8n/bin/n8n
```

The verifier creates its own `runtime-*` directory and does not use existing n8n data. It starts a local HTTP fixture, imports synthetic workflows, runs them, stops the fixture and writes the results to `evidence/`. Runtime directories and raw logs are local diagnostic artifacts and are excluded from the sharing archive.

To inspect the sample in an existing local n8n editor, first run `python fixture_server.py`, then import `workflow.json` and execute the manual trigger. Its destination is `http://127.0.0.1:8850`. Stop the fixture with Ctrl+C. Do not import into a production instance.

`build_workflow.py` produces the sample JSON. `verify.py --case C08` runs only the actual-timeout case while diagnosing. The browser fixture's shared case definitions live one directory above in `core.mjs`.

Run the additional experiment:

```text
python ledger.test.py
python verify.py --node node --n8n-bin /absolute/path/to/node_modules/n8n/bin/n8n --durable --out evidence-durable
```

SQLite fixture files live inside the verifier's isolated `runtime-*` folder and are excluded from the sharing archive. The browser UI still runs its original 12 in-memory cases; it does not load these durable results.
