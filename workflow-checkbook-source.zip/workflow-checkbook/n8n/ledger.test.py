"""Real loopback HTTP tests for the optional synthetic destination ledger."""
import concurrent.futures
import json
import socket
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from fixture_server import create_server


class LedgerContracts(unittest.TestCase):
    def setUp(self):
        self.test_root = Path(__file__).resolve().parent / 'runtime-ledger-tests'
        self.test_root.mkdir(exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(prefix='case-', dir=self.test_root)
        self.path = Path(self.tmp.name) / 'ledger.sqlite3'
        self.start()

    def start(self):
        self.server = create_server(ledger_path=self.path)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)

    def tearDown(self):
        self.stop()
        assert Path(self.tmp.name).resolve().is_relative_to(self.test_root.resolve())
        self.tmp.cleanup()

    def request(self, event='one', quantity=2, behavior='success', timeout=5, scope='durable'):
        data = json.dumps({'eventId': event, 'items': [{'sku': 'A', 'quantity': quantity}]}).encode()
        req = urllib.request.Request(f'http://127.0.0.1:{self.server.server_port}/cases/{scope}',
                                     data=data, headers={'Content-Type': 'application/json', 'X-Fixture-Behavior': behavior})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as error:
            return error.code, json.load(error)

    def test_post_commit_timeout_then_restart_replays_original_order(self):
        with self.assertRaises((TimeoutError, socket.timeout)):
            self.request(behavior='post_write_timeout', timeout=.25)
        original = self.server.snapshot('durable')['effects']
        self.assertEqual(len(original), 1, 'The timeout must occur after the actual write')
        self.stop(); self.start()
        status, body = self.request()
        self.assertEqual(status, 200)
        self.assertTrue(body['replay'])
        self.assertEqual(body['orderId'], original[0]['orderId'])
        self.assertEqual(len(self.server.snapshot('durable')['effects']), 1)

    def test_sixteen_concurrent_duplicate_requests_have_one_effect(self):
        barrier = threading.Barrier(16)
        def send(_):
            barrier.wait(timeout=5)
            return self.request()
        with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
            replies = list(pool.map(send, range(16)))
        self.assertEqual({status for status, _ in replies}, {200})
        self.assertEqual(len({body['orderId'] for _, body in replies}), 1)
        self.assertEqual(sum(not body['replay'] for _, body in replies), 1)
        self.assertEqual(len(self.server.snapshot('durable')['effects']), 1)

    def test_concurrent_conflicting_payloads_do_not_silently_succeed(self):
        barrier = threading.Barrier(2)
        def send(quantity):
            barrier.wait(timeout=5)
            return self.request(quantity=quantity)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            replies = list(pool.map(send, [2, 3]))
        self.assertEqual(sorted(status for status, _ in replies), [200, 409])
        self.assertEqual(len(self.server.snapshot('durable')['effects']), 1)

    def test_same_event_is_independent_in_distinct_scopes(self):
        a, b = self.request(scope='A'), self.request(scope='B')
        self.assertEqual((a[0], b[0]), (200, 200))
        self.assertNotEqual(a[1]['orderId'], b[1]['orderId'])
        self.assertEqual(len(self.server.snapshot('A')['effects']), 1)
        self.assertEqual(len(self.server.snapshot('B')['effects']), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
