"""Importable manual-trigger n8n sample. Synthetic destination only."""
import json
from pathlib import Path

VALIDATE = r"""
const request = $input.first().json;
const p = request.payload;
let valid = !!p && typeof p === 'object' && !Array.isArray(p) &&
  typeof p.eventId === 'string' && !!p.eventId.trim() &&
  Array.isArray(p.items) && p.items.length > 0 && p.items.length <= 100;
if (valid) valid = p.items.every(i => i && typeof i.sku === 'string' && !!i.sku.trim() &&
  Number.isSafeInteger(i.quantity) && i.quantity >= 1 && i.quantity <= 10000);
const order = valid ? {eventId:p.eventId.trim(),items:p.items.map(i => ({sku:i.sku.trim(),quantity:i.quantity}))} : null;
return [{json:{...request,valid,order}}];
"""

CLASSIFY = r"""
const r = $input.first().json;
const output = (status,outcome,body={}) => [{json:{status,body:{outcome,...body}}}];
if (r.error) {
  const code = r.error.code || r.error.cause?.code || '';
  const timeout = ['ETIMEDOUT','ECONNABORTED','ESOCKETTIMEDOUT'].includes(code);
  return output(timeout ? 504 : 502,'retryable_failure',{transportCode:code || 'unclassified'});
}
if (r.statusCode === 409) return output(409,'conflict');
if (r.statusCode === 429) {
  const delay = Number(r.headers?.['retry-after']);
  return output(429,'deferred',Number.isFinite(delay) && delay >= 0 ? {retryAfter:delay} : {});
}
if (r.statusCode >= 500) return output(502,'retryable_failure');
if (r.statusCode !== 200 || r.body?.accepted !== true || typeof r.body?.orderId !== 'string')
  return output(422,'declined');
return output(200,'confirmed',{orderId:r.body.orderId,replay:r.body.replay === true});
"""

def workflow(payload, behavior="success", case_id="demo", port=8850, ident="workflowCheckbookDemo"):
    def node(name, kind, version, position, parameters, **extra):
        return dict(id=name.replace(' ','').lower(),name=name,type='n8n-nodes-base.'+kind,
                    typeVersion=version,position=position,parameters=parameters,**extra)
    nodes = [
        node('Manual sample','manualTrigger',1,[0,0],{}),
        node('Synthetic input','set',3.4,[220,0],{'mode':'raw','jsonOutput':json.dumps(dict(payload=payload,behavior=behavior,caseId=case_id)),'options':{}}),
        node('Validate order','code',2,[440,0],{'jsCode':VALIDATE}),
        node('Valid order','if',2.2,[660,0],{'conditions':{'options':{'caseSensitive':True,'leftValue':'','typeValidation':'strict','version':2},'conditions':[{'id':'valid','leftValue':'={{ $json.valid }}','rightValue':'','operator':{'type':'boolean','operation':'true','singleValue':True}}],'combinator':'and'},'options':{}}),
        node('Destination','httpRequest',4.2,[900,-120],{
            'method':'POST','url':f'=http://127.0.0.1:{port}/cases/'+'{{ $json.caseId }}',
            'sendHeaders':True,'headerParameters':{'parameters':[{'name':'X-Fixture-Behavior','value':'={{ $json.behavior }}'}]},
            'sendBody':True,'specifyBody':'json','jsonBody':'={{ $json.order }}',
            'options':{'timeout':250,'response':{'response':{'fullResponse':True,'neverError':True,'responseFormat':'json'}}}},
            retryOnFail=False,onError='continueRegularOutput'),
        node('Classify outcome','code',2,[1140,-120],{'jsCode':CLASSIFY}),
        node('Reject input','code',2,[900,150],{'jsCode':"return [{json:{status:400,body:{outcome:'invalid'}}}];"}),
    ]
    def edge(target): return {'node':target,'type':'main','index':0}
    connections = {a:{'main':[[edge(b)]]} for a,b in [('Manual sample','Synthetic input'),('Synthetic input','Validate order'),('Validate order','Valid order'),('Destination','Classify outcome')]}
    connections['Valid order']={'main':[[edge('Destination')],[edge('Reject input')]]}
    return dict(id=ident,name='Workflow Checkbook — synthetic order intake',nodes=nodes,connections=connections,active=False,settings={'executionOrder':'v1'},pinData={},tags=[])

if __name__ == '__main__':
    target=Path(__file__).with_name('workflow.json')
    target.write_text(json.dumps(workflow({'eventId':'evt-demo-01','items':[{'sku':'DEMO-A','quantity':2}]}),indent=2)+'\n',encoding='utf-8')
