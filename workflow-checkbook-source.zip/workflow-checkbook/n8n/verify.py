"""Run the 12 browser-fixture contracts through actual isolated n8n executions."""
import argparse
import json
import os
import secrets
import socket
import subprocess
import threading
import time
import uuid
from datetime import datetime,timezone
from pathlib import Path
from build_workflow import workflow
from fixture_server import create_server

ROOT=Path(__file__).resolve().parent
def timestamp(): return datetime.now(timezone.utc).isoformat()
def execution_from_log(text):
    decoder=json.JSONDecoder()
    for i,char in enumerate(text):
        if char!='{' or (i and text[i-1]!='\n'): continue
        try: value,_=decoder.raw_decode(text[i:])
        except ValueError: continue
        if isinstance(value,dict) and isinstance(value.get('data'),dict) and 'resultData' in value['data']: return value
    raise AssertionError('Execution object missing; inspect actual log')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--node',default='node'); p.add_argument('--n8n-bin',required=True,type=Path)
    p.add_argument('--case'); p.add_argument('--out',type=Path,default=ROOT/'evidence')
    p.add_argument('--durable',action='store_true',help='Use a SQLite fixture ledger and add post-write/restart cases')
    args=p.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    raw=subprocess.check_output([args.node,'--input-type=module','-e',"import {scenarios} from './core.mjs'; process.stdout.write(JSON.stringify(scenarios()));"],cwd=ROOT.parent,text=True,encoding='utf-8')
    candidates=json.loads(raw)
    if args.durable:
        payload={'eventId':'evt-post-commit','items':[{'sku':'A','quantity':2}]}
        candidates.extend([
            {'id':'C13','name':'Post-write timeout, restart, then identical retry','steps':[
                {'payload':payload,'behavior':'post_write_timeout','restart_after':True,
                 'expect':{'status':504,'outcome':'retryable_failure','effects':1}},
                {'payload':payload,'behavior':'success',
                 'expect':{'status':200,'outcome':'confirmed','effects':1,'replay':True}}]},
            {'id':'C14','name':'Post-write timeout then changed payload conflict','steps':[
                {'payload':payload,'behavior':'post_write_timeout',
                 'expect':{'status':504,'outcome':'retryable_failure','effects':1}},
                {'payload':{'eventId':'evt-post-commit','items':[{'sku':'A','quantity':3}]},'behavior':'success',
                 'expect':{'status':409,'outcome':'conflict','effects':1}}]}
        ])
    cases=[c for c in candidates if not args.case or c['id']==args.case]
    if not cases: p.error('Unknown case')
    # New workspace-owned data only. Retain it locally for diagnosis, never use another instance.
    private=ROOT/('runtime-'+uuid.uuid4().hex[:12]); private.mkdir()
    ledger_path=private/'destination.sqlite3' if args.durable else None
    server=create_server(ledger_path=ledger_path); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    prefixes=('N8N_','DB_','EXECUTIONS_','QUEUE_','BINARY_DATA_','EXTERNAL_HOOK_FILES')
    env={k:v for k,v in os.environ.items() if not k.startswith(prefixes)}
    with socket.socket() as sock: sock.bind(('127.0.0.1',0)); broker_port=sock.getsockname()[1]
    env.update(N8N_USER_FOLDER=str(private/'instance'),DB_TYPE='sqlite',N8N_ENCRYPTION_KEY=secrets.token_hex(32),
               N8N_DIAGNOSTICS_ENABLED='false',N8N_VERSION_NOTIFICATIONS_ENABLED='false',N8N_TEMPLATES_ENABLED='false',
               N8N_PERSONALIZATION_ENABLED='false',N8N_LISTEN_ADDRESS='127.0.0.1',N8N_HOST='127.0.0.1',
               N8N_RUNNERS_BROKER_LISTEN_ADDRESS='127.0.0.1',N8N_RUNNERS_BROKER_PORT=str(broker_port),N8N_LOG_LEVEL='info')
    summary={'started_utc':timestamp(),'cases':[],'provenance':'Actual n8n CLI manual-trigger execution + loopback synthetic HTTP destination. No customer system tested.',
             'limits':['Destination owns in-memory replay state. No restart durability or concurrent execution claim.','Injected timeout occurs before any write. Unknown post-write outcomes are not covered.','No webhook entry, hosted deployment, voice platform, live call or LLM behavior tested.']}
    if args.durable:
        summary['limits']=[
            'Optional SQLite destination stores the business row and replay record atomically. This does not prove exactly-once external effects.',
            'C13 covers a clean destination-server restart, not host/power failure, a crash during commit or distributed workers.',
            'CLI executions are sequential; separate ledger.test.py exercises concurrent HTTP destination requests.',
            'Manual trigger only; no hosted deployment, customer/voice/LLM system or production traffic tested.']
        summary['destination']='SQLite synthetic ledger'
    def cli(label,arguments):
        start=time.monotonic()
        result=subprocess.run([args.node,str(args.n8n_bin.resolve()),*arguments],cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
        text=result.stdout+'\n'+result.stderr
        (args.out/(label+'.log')).write_text(text,encoding='utf-8')
        return result.returncode,text,round(time.monotonic()-start,3)
    try:
        code,version,_=cli('version',['--version']); assert code==0 and version.strip()=='2.38.7',version
        summary['n8n_version']=version.strip()
        summary['node_version']=subprocess.check_output([args.node,'--version'],text=True).strip()
        workflows=[]
        for case in cases:
            for i,step in enumerate(case['steps']):
                workflows.append(workflow(step['payload'],step['behavior'],case['id'],server.server_port,ident=f"wc{case['id']}s{i+1}"))
        path=private/'workflows.json'; path.write_text(json.dumps(workflows),encoding='utf-8')
        code,output,_=cli('import',['import:workflow','--input='+str(path)])
        assert code==0 and 'Successfully imported' in output,output[-1500:]
        for case in cases:
            observed=[]
            for i,step in enumerate(case['steps']):
                label=f"{case['id']}-step{i+1}"
                code,raw,elapsed=cli(label,['execute',f"--id=wc{case['id']}s{i+1}",'--rawOutput'])
                result=execution_from_log(raw)['data']['resultData']; data=result.get('runData',{})
                assert not result.get('error'),(label,result.get('error'))
                branch='Reject input' if step['expect']['status']==400 else 'Classify outcome'
                actual=data[branch][0]['data']['main'][0][0]['json']
                snapshot=server.snapshot(case['id'])
                fields={'status':actual['status'],'outcome':actual['body']['outcome'],'effects':len(snapshot['effects'])}
                for key in ('replay','retryAfter'):
                    if key in step['expect']: fields[key]=actual['body'].get(key)
                differences=[{'field':k,'expected':v,'actual':fields.get(k)} for k,v in step['expect'].items() if fields.get(k)!=v]
                if branch=='Reject input' and ('Destination' in data or snapshot['attempts']): differences.append({'error':'Invalid input reached destination'})
                if observed and snapshot['effects'] and observed[0]['destination']['effects']:
                    if snapshot['effects'][0]['orderId'] != observed[0]['destination']['effects'][0]['orderId']:
                        differences.append({'error':'Original order ID changed across retry'})
                item={'step':i+1,'expected':step['expect'],'actual':fields,'output':actual,'destination':snapshot,'executed_nodes':list(data),'seconds':elapsed,'cli_exit_code':code,'differences':differences,'passed':not differences}
                observed.append(item); print(json.dumps({'case':case['id'],**item},ensure_ascii=True),flush=True)
                if step.get('restart_after'):
                    old_port=server.server_port
                    server.shutdown(); server.server_close(); thread.join(timeout=5)
                    assert not thread.is_alive(), 'Previous destination loop still running'
                    server=create_server(old_port,ledger_path=ledger_path)
                    thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
                    item['destination_restarted_after_step']=True
            summary['cases'].append({'id':case['id'],'name':case['name'],'passed':all(x['passed'] for x in observed),'observations':observed})
            (args.out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=5)
        summary.update(finished_utc=timestamp(),total=len(cases),passed=sum(c['passed'] for c in summary['cases']),local_server_stopped=not thread.is_alive())
        summary['all_passed']=summary['passed']==len(cases) and len(summary['cases'])==len(cases)
        (args.out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    if not summary['all_passed']: raise SystemExit(1)

if __name__=='__main__': main()
